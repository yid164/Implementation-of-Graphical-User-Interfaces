package com.example.ken.sketchera4;

import android.view.MotionEvent;
import android.view.View;
import android.widget.SeekBar;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecutre Section: CMPT 381

public class SketchViewController implements View.OnTouchListener {

    int state;
    final int STATE_READY = 0;
    final int STATE_DRAW = 1;
    final int STATE_SELECTION = 2;
    final int STATE_BACKGROUND =3;
    float touchX;
    float touchY;
    SketchModel model;
    InteractionModel iModel;
    SketchView view;
    SketchPath found;


    public SketchViewController(){
        state=STATE_READY;
    }
    public void setiModel(InteractionModel iModel)
    {
        this.iModel = iModel;
    }
    public void setModel(SketchModel sm)
    {
        model=sm;
    }

    public void setView(SketchView aView)
    {
        view =aView;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event)
    {
        touchX = event.getX();
        touchY = event.getY();
        switch (state)
        {
            case STATE_READY:
                switch (event.getAction())
                {
                    case MotionEvent.ACTION_DOWN:
                        if (model.contains(touchX,touchY)&&found == null)
                        {
                            view.setSelection(found=model.getPath(touchX,touchY));
                            view.invalidate();
                            state=STATE_READY;
                        }
                        else if (!model.contains(touchX,touchY)&&!view.contains(touchX,touchY)&&found !=null)
                        {
                            state = STATE_BACKGROUND;
                        }
                        else if (view.contains(touchX,touchY)&& found !=null)
                        {
                            state = STATE_SELECTION;
                        }
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (!model.contains(touchX,touchY)&& found == null)
                        {
                            model.newPath(touchX, touchY);
                            state= STATE_DRAW;
                        }
                        break;
                }
                break;
            case STATE_DRAW:
                switch (event.getAction())
                {
                    case MotionEvent.ACTION_UP:
                        if (model.rowPoint.size()!=model.paths.size())
                        {
                            model.rowPoints.add(model.rowPoint);
                        }
                        model.setThinPoints(view.seekBar.getProgress());
                        view.invalidate();
                        found = null;
                        state = STATE_READY;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        model.addPoint(event.getX(),event.getY());
                        break;
                    case MotionEvent.ACTION_DOWN:
                        state = STATE_READY;
                        break;
                }
                break;
            case STATE_SELECTION:
                switch (event.getAction())
                {
                    case MotionEvent.ACTION_MOVE:
                        view.reDraw=true;
                        int x=(int)touchX;
                        int y =(int)touchY;
                        float changeX = (touchX-view.bottom)/ view.bottom;
                        float changeY = (touchY-view.right)/ view.right;
                        view.setOvl(x,y);
                        view.setChanged(changeX,changeY);
                        view.invalidate();
                        break;
                    case MotionEvent.ACTION_UP:
                        view.reDraw=false;
                        view.invalidate();
                        state = STATE_READY;
                        break;
                }
                break;
            case STATE_BACKGROUND:
                switch (event.getAction())
                {
                    case MotionEvent.ACTION_UP:
                        found=null;
                        view.setSelection(null);
                        view.invalidate();
                        state = STATE_READY;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        state = STATE_READY;
                        break;
                }

        }

        view.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                seekBar.setMax(10);
                model.setThinPoints(progress);
                view.invalidate();

            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        return true;
    }
}
