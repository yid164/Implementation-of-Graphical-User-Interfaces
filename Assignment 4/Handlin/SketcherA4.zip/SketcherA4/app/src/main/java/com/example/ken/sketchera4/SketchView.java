package com.example.ken.sketchera4;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.view.View;
import android.widget.SeekBar;

import java.util.ArrayList;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecutre Section: CMPT 381

public class SketchView extends View implements SketchListener {
    SketchModel model;
    InteractionModel iModel;
    SeekBar seekBar;
    SketchPath selected=null;
    Path path;
    int bottom, right, left, top;
    float changeX =0, changeY =0;
    ArrayList<SketchPath> list;
    boolean reDraw = false;
    Paint paint1;
    Paint paint2;
    public SketchView(Context aContext)
    {
        super(aContext);
        path = new Path();
        seekBar=new SeekBar(aContext);
        paint1 =new Paint();
        paint1.setStrokeWidth(3);
        paint1.setStyle(Paint.Style.STROKE);
        paint1.setColor(Color.BLACK);
        paint2 = new Paint();
        paint2.setStyle(Paint.Style.STROKE);
        paint2.setStrokeWidth(10);
        paint2.setColor(Color.BLACK);
        this.setBackgroundColor(Color.GRAY);

    }

    public void setOvl(int x, int y)
    {
        bottom =x;
        right =y;

    }
    public void setSelection(SketchPath s)
    {
        selected=s;
    }

    public void setChanged(float x, float y)
    {
        changeX =x;
        changeY =y;
    }

    public void setModel(SketchModel aModel)
    {
        model = aModel;
    }
    public void setiModel(InteractionModel aModel)
    {
        iModel = aModel;
    }
    public void onDraw(Canvas c)
    {
        if (!reDraw)
        {
            paint2.setColor(Color.BLACK);
            c.drawPath(model.path, paint2);
        }
        drawPath(c);
        if (selected !=null && !reDraw)
        {
            ArrayList<SketchPath> list = iModel.getPath(selected);
            bottom = iModel.findMaxX(list)+10;
            right = iModel.findMaxY(list)+10;
            left = iModel.findMinX(list)-10;
            top = iModel.findMinY(list)-10;
            drawSelected(c);
            drawRect(c);
            drawOvl(c);
        }
        if (reDraw&& selected!=null)
        {
            model.path =new Path();
            drawSelected(c);
            drawRect(c);
            drawOvl(c);
        }
        paint2.setColor(Color.BLACK);

    }

    public void drawPath(Canvas c)
    {
        if (model.thinPoints!=null)
        {
            for (int k = 0; k<model.paths.size(); k++)
            {
                for (int a = 0; a < model.thinPoints.size(); a++)
                {
                    float midX,midY,x1,x2,y1,y2;
                    model.paths.get(k).rewind();
                    model.paths.get(k).moveTo(model.thinPoints.get(a).get(0).x,model.thinPoints.get(a).get(0).y);
                    for (int i =1;i<model.thinPoints.get(a).size()-2;i++){
                        paint2.setColor(Color.RED);
                        x1=model.thinPoints.get(a).get(i).x;
                        y1=model.thinPoints.get(a).get(i).y;
                        x2=model.thinPoints.get(a).get(i+1).x;
                        y2=model.thinPoints.get(a).get(i+1).y;
                        midX = (x1+x2)/2;
                        midY = (y1+y2)/2;
                        model.paths.get(k).quadTo(x1,y1,midX,midY);
                        model.paths.get(k).moveTo(midX,midY);
                    }
                    x1=model.thinPoints.get(a).get(model.thinPoints.get(a).size()-2).x;
                    y1=model.thinPoints.get(a).get(model.thinPoints.get(a).size()-2).y;
                    x2=model.thinPoints.get(a).get(model.thinPoints.get(a).size()-1).x;
                    y2=model.thinPoints.get(a).get(model.thinPoints.get(a).size()-1).y;
                    midX = (x1+x2)/2;
                    midY = (y1+y2)/2;
                    model.paths.get(k).quadTo(x1,y1,midX,midY);
                    model.paths.get(k).moveTo(midX,midY);
                    c.drawPath(model.paths.get(k), paint2);
                }
            }
        }
    }


    public void drawSelected(Canvas c)
    {
        list = iModel.getPath(selected);
        for (int i =0;i<list.size();i++)
        {
            list.get(i).x=list.get(i).x+(list.get(i).x* changeX);
            list.get(i).y=list.get(i).y+(list.get(i).y* changeY);
        }
        for (int i =0;i<list.size()-2;i++)
        {
            paint2.setColor(Color.BLUE);
            float x = (list.get(i+1).x+list.get(i+2).x)/2;
            float y = (list.get(i+1).y+list.get(i+2).y)/2;
            path.rewind();
            path.moveTo(list.get(i).x,list.get(i).y);
            path.quadTo(list.get(i+1).x,list.get(i+1).y,x,y);
            c.drawPath(path, paint2);
        }
    }

    public void drawRect(Canvas c)
    {
        Rect abc = new Rect(left, top, bottom, right);
        c.drawRect(abc, paint1);
    }

    public void drawOvl(Canvas c)
    {
        paint1.setStyle(Paint.Style.FILL);
        int r = 20;
        c.drawOval(bottom -r, right -r, bottom +r, right +r, paint1);
        paint1.setStyle(Paint.Style.STROKE);
    }

    public boolean contains(float x, float y)
    {
        boolean find = false;
        if ((float) Math.sqrt(Math.pow((double) x - (double) bottom +20, 2) + Math.pow((double) y - (double) right +20, 2))<=50)
        {
            find=true;
        }
        return find;
    }
    public void modelChanged()
    {
        this.invalidate();
    }
}
