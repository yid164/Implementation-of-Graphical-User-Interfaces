package com.example.ken.sketchera4;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecutre Section: CMPT 381

import android.graphics.Path;

import java.util.ArrayList;

public class SketchModel {
    Path path;
    Path smoothed;
    ArrayList<SketchListener> subscribers;
    SketchView view;
    ArrayList<ArrayList<SketchPath>> thinPoints;
    ArrayList<SketchPath> rowPoint;
    ArrayList<Path> paths;
    ArrayList<ArrayList<SketchPath>> rowPoints;

    public SketchModel()
    {
        path =new Path();
        rowPoints = new ArrayList<>();
        thinPoints=new ArrayList<>();
        paths = new ArrayList<>();
        subscribers = new ArrayList<>();
    }

    public void setView(SketchView aView)
    {
        view = aView;
    }


    public void newPath(float newX, float newY)
    {
        smoothed = new Path();
        rowPoint =new ArrayList<>();
        path.moveTo(newX,newY);
        paths.add(smoothed);
        rowPoint.add(new SketchPath(newX,newY));
        notifySubscribers();
    }

    public void addPoint(float x, float y)
    {
        path.lineTo(x,y);
        rowPoint.add(new SketchPath(x,y));
        notifySubscribers();
    }



    public SketchPath getPath(float x, float y)
    {
        SketchPath path = null;
        for (int i = 0; i< rowPoints.size(); i++)
        {
            for (SketchPath path1 : rowPoints.get(i))
            {
                if (path1.contains(x,y))
                {
                    path = path1;
                }
            }
        }
        return path;
    }




    public boolean contains(float x, float y)
    {
        boolean found=false;
        for (int i = 0; i< rowPoints.size(); i++)
        {
            for (SketchPath path : rowPoints.get(i))
            {
                if (path.contains(x,y))
                {
                    found=true;
                }
            }
        }
        return found;
    }


    public void setThinPoints(int t)
    {
        switch (t)
        {
            case 0:
                for (Path path : paths)
                {
                    path.rewind();
                }
                for (int i = 0; i< rowPoints.size(); i++)
                {
                    thinPoints.add(rowPoints.get(i));
                }
            case 1:
                thinPoints=new ArrayList<>();
                for (int i = 0; i< rowPoints.size(); i++)
                {
                    thinPoints.add(rowPoints.get(i));
                }
                break;
            case 2:
                thinPoints=new ArrayList<>();
                for (int i = 0; i< rowPoints.size(); i++){
                    ArrayList<SketchPath> path = new ArrayList<>();
                    for (int a = 0; a< rowPoints.get(i).size(); a+=2)
                    {
                        path.add(rowPoints.get(i).get(a));
                    }
                    path.add(rowPoints.get(i).get(rowPoints.get(i).size()-1));
                    thinPoints.add(path);
                }
                break;
            case 3:
                thinPoints=new ArrayList<>();
                for (int i = 0; i< rowPoints.size(); i++){
                    ArrayList<SketchPath> path = new ArrayList<>();
                    for (int a = 0; a< rowPoints.get(i).size(); a+=3)
                    {
                        path.add(rowPoints.get(i).get(a));
                    }
                    path.add(rowPoints.get(i).get(rowPoints.get(i).size()-1));
                    thinPoints.add(path);
                }
                break;
            case 4:
                thinPoints=new ArrayList<>();
                for (int i = 0; i< rowPoints.size(); i++){
                    ArrayList<SketchPath> path = new ArrayList<>();
                    for (int a = 0; a< rowPoints.get(i).size(); a+=4)
                    {
                        path.add(rowPoints.get(i).get(a));
                    }
                    path.add(rowPoints.get(i).get(rowPoints.get(i).size()-1));
                    thinPoints.add(path);
                }
                break;
            case 5:
                thinPoints=new ArrayList<>();
                for (int i = 0; i< rowPoints.size(); i++){
                    ArrayList<SketchPath> path = new ArrayList<>();
                    for (int a = 0; a< rowPoints.get(i).size(); a+=5)
                    {
                        path.add(rowPoints.get(i).get(a));
                    }
                    path.add(rowPoints.get(i).get(rowPoints.get(i).size()-1));
                    thinPoints.add(path);
                }
                break;
            case 6:
                thinPoints=new ArrayList<>();
                for (int i = 0; i< rowPoints.size(); i++){
                    ArrayList<SketchPath> path = new ArrayList<>();
                    for (int a = 0; a< rowPoints.get(i).size(); a+=6)
                    {
                        path.add(rowPoints.get(i).get(a));
                    }
                    path.add(rowPoints.get(i).get(rowPoints.get(i).size()-1));
                    thinPoints.add(path);
                }
                break;
            case 7:
                thinPoints=new ArrayList<>();
                for (int i = 0; i< rowPoints.size(); i++){
                    ArrayList<SketchPath> path = new ArrayList<>();
                    for (int a = 0; a< rowPoints.get(i).size(); a+=7)
                    {
                        path.add(rowPoints.get(i).get(a));
                    }
                    path.add(rowPoints.get(i).get(rowPoints.get(i).size()-1));
                    thinPoints.add(path);
                }
                break;
            case 8:
                thinPoints=new ArrayList<>();
                for (int i = 0; i< rowPoints.size(); i++){
                    ArrayList<SketchPath> path = new ArrayList<>();
                    for (int a = 0; a< rowPoints.get(i).size(); a+=8)
                    {
                        path.add(rowPoints.get(i).get(a));
                    }
                    path.add(rowPoints.get(i).get(rowPoints.get(i).size()-1));
                    thinPoints.add(path);
                }
                break;
            case 9:
                thinPoints=new ArrayList<>();
                for (int i = 0; i< rowPoints.size(); i++)
                {
                    ArrayList<SketchPath> path = new ArrayList<>();
                    for (int a = 0; a< rowPoints.get(i).size(); a+=9)
                    {
                        path.add(rowPoints.get(i).get(a));
                    }
                    path.add(rowPoints.get(i).get(rowPoints.get(i).size()-1));
                    thinPoints.add(path);
                }
                break;
            case 10:
                thinPoints=new ArrayList<>();
                for (int i = 0; i< rowPoints.size(); i++)
                {
                    ArrayList<SketchPath> path = new ArrayList<>();
                    for (int a = 0; a< rowPoints.get(i).size(); a+=10)
                    {
                        path.add(rowPoints.get(i).get(a));
                    }
                    path.add(rowPoints.get(i).get(rowPoints.get(i).size()-1));
                    thinPoints.add(path);
                }
                break;
        }

    }


    public void addSubscriber(SketchListener sl)
    {
        subscribers.add(sl);
    }

    private void notifySubscribers()
    {
        for (SketchListener sl : subscribers)
        {
            sl.modelChanged();
        }
    }



}
