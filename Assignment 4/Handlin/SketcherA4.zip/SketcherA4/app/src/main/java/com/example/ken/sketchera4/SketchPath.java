package com.example.ken.sketchera4;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecutre Section: CMPT 381

public class SketchPath {
    float x;
    float y;
    float r;

    public float distance(float x1, float y1, float x2, float y2)
    {
        return (float) Math.sqrt(Math.pow((double) x2 - (double) x1, 2) + Math.pow((double) y2 - (double) y1, 2));
    }


    public boolean contains(float tx, float ty)
    {
        return distance(x,y,tx,ty)<= r;
    }

    public SketchPath(float tx, float ty)
    {
        x = tx;
        y = ty;
        r = 15;
    }



}
