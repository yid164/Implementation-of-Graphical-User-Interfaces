package com.example.ken.sketchera4;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecutre Section: CMPT 381
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;


public class SketcherMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SketchView view = new SketchView(this);
        SketchModel model = new SketchModel();
        InteractionModel iModel = new InteractionModel();
        SketchViewController controller = new SketchViewController();
        controller.setModel(model);
        controller.setView(view);
        controller.setiModel(iModel);
        model.addSubscriber(view);
        model.setView(view);
        view.setModel(model);
        view.setiModel(iModel);
        view.setOnTouchListener(controller);
        iModel.setView(view);
        iModel.setIModel(model);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(view.seekBar, new LinearLayout.LayoutParams(1100, 50));
        layout.addView(view, new LinearLayout.LayoutParams(1100, 1550));
        setContentView(layout);
    }
}
