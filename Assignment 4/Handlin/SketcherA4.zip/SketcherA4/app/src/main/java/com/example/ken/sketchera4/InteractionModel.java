package com.example.ken.sketchera4;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecutre Section: CMPT 381

import java.util.ArrayList;

public class InteractionModel {
    SketchModel model;
    SketchView view;
    

    public void setIModel(SketchModel aModel)
    {
        model=aModel;
    }
    public void setView(SketchView aView)
    {
        view =aView;
    }

    public ArrayList<SketchPath> getPath(SketchPath path)
    {
        ArrayList<SketchPath> found=null;
        for (int i = 0; i<model.rowPoints.size(); i++)
        {
            for (int s = 0; s<model.rowPoints.get(i).size(); s++)
            {
                if (path == model.rowPoints.get(i).get(s))
                {
                    found=model.rowPoints.get(i);
                }
            }
        }
        return found;
    }



    public int findMaxX(ArrayList<SketchPath> list)
    {
        int x=0;
        for (int i=0; i<list.size();i++)
        {
            if (list.get(i).x>x)
            {
                x=(int)list.get(i).x;
            }
        }
        return x;
    }
    public int findMaxY(ArrayList<SketchPath> list)
    {
        int y=0;
        for (int i=0; i<list.size();i++){
            if (list.get(i).y>y){
                y=(int)list.get(i).y;
            }
        }
        return y;
    }

    public int findMinX(ArrayList<SketchPath> list)
    {
        int x=1000;
        for (int i=0; i<list.size();i++)
        {
            if (list.get(i).x<x)
            {
                x=(int)list.get(i).x;
            }
        }
        return x;
    }
    public int findMinY(ArrayList<SketchPath> list)
    {
        int y=1000;
        for (int i=0; i<list.size();i++)
        {
            if (list.get(i).y<y)
            {
                y=(int)list.get(i).y;
            }
        }
        return y;
    }


    public InteractionModel()
    {
        model = null;
        view = null;

    }
}
