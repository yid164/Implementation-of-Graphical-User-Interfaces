package com.example.ken.sketchera4;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecutre Section: CMPT 381

public interface SketchListener {
    void modelChanged();
}
