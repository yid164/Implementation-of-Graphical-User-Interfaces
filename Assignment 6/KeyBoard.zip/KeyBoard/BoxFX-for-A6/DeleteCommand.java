/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;

/**
 *
 * @author gutwin
 */
public class DeleteCommand implements BoxCommand {
    ArrayList<Groupable> groups;
    BoxModel model;
    double boxX, boxY;
    
    public DeleteCommand(BoxModel newModel, ArrayList<Groupable> toDelete) {
        model = newModel;
        groups = (ArrayList<Groupable>)toDelete.clone();
    }
    
    public void doIt() {
        model.deleteGroups(groups);
    }
    
    public void undo() {
        model.addGroups(groups);
    }
    
    public String toString() {
        return "Delete: " + groups.size() + " Groupables";
    }
}
