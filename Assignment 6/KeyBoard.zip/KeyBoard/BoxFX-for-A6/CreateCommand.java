/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;

/**
 *
 * @author gutwin
 */
public class CreateCommand implements BoxCommand {
    Groupable newBox;
    BoxModel model;
    double boxX, boxY;
    
    public CreateCommand(BoxModel newModel, double newX, double newY) {
        model = newModel;
        newBox = null;
        boxX = newX;
        boxY = newY;
    }
    
    public void doIt() {
        newBox = new Box(boxX, boxY);
        model.addBox(newBox);
    }
    
    public void undo() {
        model.deleteGroup(newBox);
    }
    
    public String toString() {
        return "Create: " + (int)boxX + "," + (int)boxY;
    }
}
