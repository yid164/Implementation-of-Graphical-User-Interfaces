/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;

/**
 *
 * @author gutwin
 */
public class BoxClipboard {

    ArrayList<Groupable> groups;

    public BoxClipboard() {
        groups = new ArrayList<Groupable>();
    }

    public void copy2(ArrayList<Groupable> gs) {
        groups.clear();
        System.out.println("about to add list of " + gs.size() + " to clip");

        for (Groupable g : gs) {
            if (g.hasChildren()) {
                // group
                groups.add(new Group(g));
            } else {
                // box
                groups.add(new Box(g));
                System.out.println("adding Box to clip");
            }
        }
    }

    public void copy(ArrayList<Groupable> gs) {
        groups = (ArrayList<Groupable>)gs.clone();
        System.out.println("After copy, clipboard size is " + groups.size());
    }

    public void add(Groupable g) {
        groups.clear();
        groups.add(g);
    }

    public ArrayList<Groupable> get() {
        //return (ArrayList<Groupable>) groups.clone();
        System.out.println("Before get, clipboard size is " + groups.size());
        ArrayList<Groupable> copy = new ArrayList<Groupable>();
        for (Groupable g : groups) {
            if (g.hasChildren()) {
                // group
                copy.add(new Group(g));
            } else {
                // box
                copy.add(new Box(g));
            }            
        }
        return copy;
    }
}
