/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.Stack;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author gutwin
 */
public class BoxFX extends Application {
    ObservableList<String> undoItems;
    ObservableList<String> redoItems;
    BoxViewController controller;

    @Override
    public void start(Stage primaryStage) {
        BoxModel model = new BoxModel();
        BoxView view = new BoxView(700, 700);
        controller = new BoxViewController();
        view.setController(controller);
        view.setModel(model);
        model.addSubscriber(view);
        controller.setView(view);
        controller.setModel(model);
        controller.setApp(this);

        for (int i = 0; i < 10; i++) {
            model.createBox(Math.random() * 650, Math.random() * 650);
        }

        Label undoLabel = new Label("Undo Stack");
        undoLabel.setFont(Font.font(24));
        Label redoLabel = new Label("Redo Stack");
        redoLabel.setFont(Font.font(24));
        ListView<String> undoList = new ListView<String>();
        undoList.setPrefHeight(9999);
        ListView<String> redoList = new ListView<String>();
        redoList.setPrefHeight(9999);
        undoItems =FXCollections.observableArrayList ("Empty");
        redoItems =FXCollections.observableArrayList ("Empty");
        undoList.setItems(undoItems);
        redoList.setItems(redoItems);
        Button undoButton = new Button("Undo!");
        undoButton.setFont(Font.font(24));
        Button redoButton = new Button("Redo!");
        redoButton.setFont(Font.font(24));
        
        undoButton.setOnAction(controller::handleUndo);
        redoButton.setOnAction(controller::handleRedo);
        
        VBox undoVB = new VBox();
        VBox redoVB = new VBox();
        undoVB.setAlignment(Pos.CENTER);
        redoVB.setAlignment(Pos.CENTER);
        undoVB.getChildren().addAll(undoLabel,undoList,undoButton);
        redoVB.getChildren().addAll(redoLabel,redoList,redoButton);

        HBox root = new HBox();
        root.getChildren().addAll(undoVB, view, redoVB);

        Scene scene = new Scene(root,1200,700);

        primaryStage.setTitle("381 Assignment 5");
        primaryStage.setScene(scene);
        primaryStage.show();

        root.setOnKeyPressed(controller::handleKeyPressed);
        root.setOnKeyReleased(controller::handleKeyReleased);
        
        root.requestFocus();
    }
    
    public void updateUndoList(Stack<BoxCommand> undoStack) {
        undoItems.clear();
        for (int i = undoStack.size() - 1; i >= 0; i--) {
            BoxCommand bc = undoStack.get(i);
            undoItems.add(bc.toString());
        }
    }

    public void updateRedoList(Stack<BoxCommand> redoStack) {
        redoItems.clear();
        for (int i = redoStack.size() - 1; i >= 0; i--) {
            BoxCommand bc = redoStack.get(i);
            redoItems.add(bc.toString());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
