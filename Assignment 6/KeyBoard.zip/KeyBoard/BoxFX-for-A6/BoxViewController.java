/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Stack;
import javafx.event.ActionEvent;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

/**
 *
 * @author gutwin
 */
public class BoxViewController {

    BoxModel model;
    BoxView view;
    BoxFX app;
    //ArrayList<Box> selectedBoxes;
    ArrayList<Groupable> selectedGroups;
    //double clickX, clickY;
    Stack<BoxCommand> undoStack, redoStack;

    int state = 0;
    final int STATE_READY = 0;
    final int STATE_RECTSELECT = 1;
    final int STATE_ARMED = 2;
    final int STATE_DRAGGING = 3;

    boolean controlDown;
    double rectSelectX1, rectSelectY1, rectSelectX2, rectSelectY2;
    double prevX, prevY;
    double dX, dY;
    double dragStartX, dragStartY;

    BoxClipboard board;

    public BoxViewController() {
        selectedGroups = new ArrayList<Groupable>();
        controlDown = false;
        board = new BoxClipboard();
        undoStack = new Stack<BoxCommand>();
        redoStack = new Stack<BoxCommand>();
    }

    public void setModel(BoxModel bModel) {
        model = bModel;
    }

    public void setView(BoxView bView) {
        view = bView;
    }

    public void setApp(BoxFX bApp) {
        app = bApp;
    }

    public void handleUndo(ActionEvent event) {
        if (undoStack.empty()) {
            System.out.println("Nothing more to undo!");
        } else {
            BoxCommand bc = undoStack.pop();
            bc.undo();
            app.updateUndoList(undoStack);
            redoStack.push(bc);
            app.updateRedoList(redoStack);
            view.modelChanged();
        }
    }

    public void handleRedo(ActionEvent event) {
        if (redoStack.empty()) {
            System.out.println("Nothing more to redo!");
        } else {
            BoxCommand bc = redoStack.pop();
            bc.doIt();
            app.updateRedoList(redoStack);
            undoStack.push(bc);
            app.updateUndoList(undoStack);
            view.modelChanged();
        }
    }

    public void handleMousePressed(MouseEvent event) {
        prevX = event.getX();
        prevY = event.getY();
        switch (state) {
            case STATE_READY:
                // if secondary button, create
                if (event.isSecondaryButtonDown()) {
                    selectedGroups.clear();
                    //model.createBox(event.getX(), event.getY());
                    CreateCommand cc = new CreateCommand(model, event.getX(), event.getY());
                    cc.doIt();
                    undoStack.push(cc);
                    app.updateUndoList(undoStack);

                } else {
                    // add to or remove from current selection
                    if (model.contains(event.getX(), event.getY())) {
                        // click is on a box
                        // if on existing selection, a move; otherwise, select
                        if (clickOnSelection(event.getX(), event.getY())) {
                            dragStartX = event.getX();
                            dragStartY = event.getY();
                            state = STATE_DRAGGING;
                        } else {
                            if (!controlDown) {
                                selectedGroups.clear();
                            }
                            addToSelection(model.findClick(event.getX(), event.getY()));
                            state = STATE_ARMED;
                        }
                    } else {
                        // click is on the background, so start a rectangle select
                        if (!controlDown) {
                            selectedGroups.clear();
                        }
                        rectSelectX1 = event.getX();
                        rectSelectY1 = event.getY();
                        rectSelectX2 = event.getX();
                        rectSelectY2 = event.getY();
                        state = STATE_RECTSELECT;
                    }
                }
                break;
            case STATE_ARMED:
                if (controlDown) {
                    removeFromSelection(model.findClick(event.getX(), event.getY()));
                }
                break;
        }
        view.modelChanged();
    }

    private boolean clickOnSelection(double cx, double cy) {
        boolean found = false;
        for (Groupable g : selectedGroups) {
            if (g.contains(cx, cy)) {
                found = true;
            }
        }
        return found;
    }

    public void handleMouseDragged(MouseEvent event) {
        switch (state) {
            case STATE_RECTSELECT:
                rectSelectX2 = event.getX();
                rectSelectY2 = event.getY();
                break;
            case STATE_ARMED:
                // move
                dragStartX = event.getX();
                dragStartY = event.getY();

                state = STATE_DRAGGING;
                break;
            case STATE_DRAGGING:
                dX = event.getX() - prevX;
                dY = event.getY() - prevY;
                model.moveGroups(selectedGroups, dX, dY);
                prevX = event.getX();
                prevY = event.getY();
                break;
        }
        view.modelChanged();
    }

    public void handleMouseReleased(MouseEvent event) {
        switch (state) {
            case STATE_RECTSELECT:
                addRemoveSelection(model.findInRectangle(rectSelectX1, rectSelectY1, rectSelectX2, rectSelectY2));
                break;
            case STATE_ARMED:
                if (!controlDown) {
                    selectedGroups.clear();
                    addToSelection(model.findClick(event.getX(), event.getY()));
                }
                break;
            case STATE_DRAGGING:
                // finish move and create undo command
                dX = event.getX() - dragStartX;
                dY = event.getY() - dragStartY;
                //System.out.println("dragStartX: " + dragStartX + "\teventX: " + event.getX());
                MoveCommand mc = new MoveCommand(model, selectedGroups, dX, dY);
                undoStack.push(mc);
                app.updateUndoList(undoStack);
                state = STATE_READY;
        }
        state = STATE_READY;
        view.modelChanged();
    }

    public void handleKeyPressed(KeyEvent event) {
        if (event.getCode() == KeyCode.CONTROL) {
            controlDown = true;
            view.modelChanged();
        }
    }

    public void handleKeyReleased(KeyEvent event) {
        if (event.getCode() == KeyCode.CONTROL) {
            controlDown = false;
        } else if (event.getCode() == KeyCode.G) {
            System.out.println("G");
            if (selectedGroups.size() > 0) {
                Groupable tempGroup = model.createGroup(selectedGroups);
                selectedGroups.clear();
                selectedGroups.add(tempGroup);
            }
        } else if (event.getCode() == KeyCode.U) {
            System.out.println("U");
            if (selectedGroups.size() == 1 && selectedGroups.get(0).hasChildren()) {
                ArrayList<Groupable> items = model.ungroup(selectedGroups.get(0));
                selectedGroups.clear();
                addRemoveSelection(items);
            }
        } else if (event.getCode() == KeyCode.DELETE) {
            System.out.println("DELETE");
            if (selectedGroups.size() > 0) {
                DeleteCommand dc = new DeleteCommand(model, selectedGroups);
                dc.doIt();
                undoStack.push(dc);
                app.updateUndoList(undoStack);
                //model.deleteGroups(selectedGroups);
            }
        } else if (event.getCode() == KeyCode.C && event.isControlDown()) {
            System.out.println("Copy");
            if (selectedGroups.size() > 0) {
                board.copy(selectedGroups);
            }
        } else if (event.getCode() == KeyCode.V && event.isControlDown()) {
            System.out.println("Paste");
            selectedGroups.clear();
            selectedGroups = board.get();
            model.addGroups(selectedGroups);
            System.out.println("after paste, selectedGroups size: " + selectedGroups.size());

            //model.pasteGroups(selectedGroups);
        } else if (event.getCode() == KeyCode.X && event.isControlDown()) {
            System.out.println("Cut");
            if (selectedGroups.size() > 0) {
                board.copy(selectedGroups);
                model.deleteGroups(selectedGroups);
                selectedGroups.clear();
            }
            System.out.println("after cut, selectedGroups size: " + selectedGroups.size());
        }
        view.modelChanged();
    }

    private void addToSelection(Groupable sGroup) {
        if (selectedGroups.contains(sGroup)) {
            // do nothing
        } else {
            selectedGroups.add(sGroup);
        }
    }

    private void removeFromSelection(Groupable sGroup) {
        if (selectedGroups.contains(sGroup)) {
            selectedGroups.remove(sGroup);
        } else {
            //selectedGroups.add(sGroup);
        }
    }

    private void addRemoveSelection(Groupable sGroup) {
        if (selectedGroups.contains(sGroup)) {
            selectedGroups.remove(sGroup);
        } else {
            selectedGroups.add(sGroup);
        }
    }

    private void addRemoveSelection(ArrayList<Groupable> sGroups) {
        for (Groupable g : sGroups) {
            addRemoveSelection(g);
        }
    }

//    private void addRemoveSelection(Box sBox) {
//        if (selectedBoxes.contains(sBox)) {
//            selectedBoxes.remove(sBox);
//        } else {
//            selectedBoxes.add(sBox);
//        }
//    }
//
//    private void addRemoveSelection(ArrayList<Box> sBoxes) {
//        for (Box b : sBoxes) {
//            addRemoveSelection(b);
//        }
//    }
    double distance(double x1, double y1, double x2, double y2) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        return Math.sqrt(dx * dx + dy * dy);
    }
}
