/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;

/**
 *
 * @author gutwin
 */
public class MoveCommand implements BoxCommand {
    ArrayList<Groupable> groups;
    BoxModel model;
    double dx, dy;
    
    public MoveCommand(BoxModel newModel, ArrayList<Groupable> newGroups, double newDX, double newDY) {
        model = newModel;
        groups = (ArrayList<Groupable>)newGroups.clone();
        dx = newDX;
        dy = newDY;
    }
    
    public void doIt() {
        model.moveGroups(groups, dx, dy);
    }
    
    public void undo() {
        model.moveGroups(groups, dx*-1, dy*-1);
    }
    
    public String toString() {
        return "Move: " + (int)dx + "," + (int)dy;
    }
}
