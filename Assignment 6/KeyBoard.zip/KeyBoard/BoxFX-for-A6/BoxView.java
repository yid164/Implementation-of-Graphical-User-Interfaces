/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.TextAlignment;

/**
 *
 * @author gutwin
 */
public class BoxView extends Pane implements BoxModelListener {

    BoxModel model;
    BoxViewController controller;
    GraphicsContext gc;
    Canvas boxCanvas;

    public BoxView(double width, double height) {
        boxCanvas = new Canvas(width, height);
        gc = boxCanvas.getGraphicsContext2D();

        getChildren().add(boxCanvas);
    }

    private void drawShapes() {
        // background
        gc.setFill(Color.DARKGREY);
        gc.fillRect(0, 0, boxCanvas.getWidth(), boxCanvas.getHeight());

        // groups
        for (Groupable g : model.groups) {
            if (controller.selectedGroups.contains(g)) {
                gc.setFill(Color.BLUE);
            } else {
                gc.setFill(Color.ORANGE);
            }
            g.drawGroup(gc);
        }

        // rectangle select
        gc.setStroke(Color.YELLOW);
        if (controller.state == controller.STATE_RECTSELECT) {
            gc.strokeRect(controller.rectSelectX1, controller.rectSelectY1,
                    controller.rectSelectX2 - controller.rectSelectX1, controller.rectSelectY2 - controller.rectSelectY1);
        }
        gc.setFill(Color.BLACK);

        // CTRL state
        gc.setFont(Font.font(24));
        if (controller.controlDown) {
            gc.fillText("CONTROL", 20, 40);
        }
        //gc.fillText("Selection size: " + controller.selectedGroups.size(), 320, 40);
    }

    public void setModel(BoxModel aModel) {
        model = aModel;
    }

    public void setController(BoxViewController bvc) {
        controller = bvc;
        boxCanvas.setOnMousePressed(controller::handleMousePressed);
        boxCanvas.setOnMouseReleased(controller::handleMouseReleased);
        boxCanvas.setOnMouseDragged(controller::handleMouseDragged);
    }

    public void modelChanged() {
        drawShapes();
    }
}
