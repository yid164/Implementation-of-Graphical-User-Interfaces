// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lectrue Section: CMPT381
package keyboard;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author yid164
 */
public class TrieNode {
    char content;
    boolean isLeaf;
    int charCount;
    int wordCount;
    String[] allFit;
    ArrayList<String> typeAhead;
    LinkedList<TrieNode> childList;

    public TrieNode(char c) {
        childList = new LinkedList<>();
        isLeaf = false;
        content = c;
        charCount = 0;
        wordCount = 0;
    }

    public TrieNode getChild(char c) {
        TrieNode target = null;
        if (childList != null) {
            for (TrieNode child : childList) {
                if (child.content == c) {
                    target = child;
                }
            }
        }
        return target;
    }

    public void printNode(String space) {
        if (isLeaf) {
            System.out.println(space + content + "(" + charCount + "/" + wordCount + ")");
        } else {
            System.out.println(space + content + "(" + charCount + ")");
        }
        for (TrieNode child : childList) {
            child.printNode(space + "..");
        }
    }
    
    
    public void setAllFit(String[] fits)
    {
        allFit = fits;
    }
}
