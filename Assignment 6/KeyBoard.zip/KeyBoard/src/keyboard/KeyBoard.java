// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lectrue Section: CMPT381
package keyboard;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author yid164
 */
public class KeyBoard extends Application {
    
    Trie trie;
    KeyBoardView view;
    
    @Override
    public void start(Stage primaryStage) {

        view = new KeyBoardView();
        StackPane root = new StackPane();
        root.getChildren().add(view);
        
        Scene scene = new Scene(root, 700, 480);
        
        primaryStage.setTitle("Code KeyBoard");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
