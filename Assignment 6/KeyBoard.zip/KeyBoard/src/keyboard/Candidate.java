// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lectrue Section: CMPT381
package keyboard;

/**
 * Candidate class to hold on the candidate' name and frequency,
 * implements the comparable interface for sorting the candidates by frequecy
 * @author yid164
 */
public class Candidate implements Comparable<Candidate> {
    
    String candidate;
    Integer frequency;
    
    
    public Candidate(String name, Integer f)
    {
        candidate = name;
        frequency = f;
    }
    
    public boolean isSameCandidateName(Candidate c)
    {
        return candidate.equals(c.candidate);
    }
    
    public void setCandidate(String name)
    {
        candidate = name;
    }
    
    public void setFrequency(Integer f)
    {
        frequency = f;
    }
    
    public String getCandidateName()
    {
        return candidate;
    }
    
    public Integer getFrequency()
    {
        return frequency;
    }
    
    @Override
    public String toString()
    {
        return candidate + "(" + frequency + ")";
    }

    @Override
    public int compareTo(Candidate c) {
        return frequency.compareTo(c.frequency);
    }

    
    
}
