// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lectrue Section: CMPT381
package keyboard;

import java.util.ArrayList;
import java.util.Collections;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

/**
 * KeyBoard view for the assignment
 * @author yid164
 */
public class KeyBoardView extends Pane {
    
    // first lane of the keyboard(symbols)
    public Button[] symbolLane1;
    // second lane of the keyboard(symbols)
    public Button[] symbolLane2;
    // thrid lane of the keyboard (numbers)
    public Button[] numberLane;
    // fourth lane of the keyboard (letters)
    public Button[] letterLane1;
    // fifth lane of the keyboard (letters)
    public Button[] letterLane2;
    // sith lane of the keyboard (letters)
    public Button[] letterLane3;
    // delete button 
    public Button delete;
    // left shift button
    public Button leftShift;
    // right shift button
    public Button rightShift;
    // space button
    public Button space;
    // text field that user input
    public TextField textField;
    // tops three labels of the part 2
    public Label label1;
    public Label label2;
    public Label label3;
    // helper string for the text filed
    public String text;
    // shift varibles to do the case swtich 
    public final int SHIFTOFF = 0;
    public final int SHIFTON = 1;
    public int shift;
    // Candidate arraylist that to get suggestions
    public ArrayList<Candidate> suggestions;
    // call the trie method
    Trie trie;
   
    /**
     * constractor to organise the key board view
     */
    public KeyBoardView()
    {
        createKeyBoard();
        trie = new Trie();
        trie.readFile();
        trie.sortCandidates();
        label1 = new Label();
        label1.setPrefSize(220, 50);
        label2 = new Label();
        label2.setPrefSize(220, 50);
        label3 = new Label();
        label3.setPrefSize(220, 50);
        HBox topLabels = new HBox();
        topLabels.setPrefSize(700, 50);
        label1.setFont(Font.font(18));
        label2.setFont(Font.font(18));
        label3.setFont(Font.font(18));
        label1.setAlignment(Pos.CENTER_LEFT);
        label1.setOnMouseClicked(this::handleLable);
        label2.setAlignment(Pos.CENTER);
        label2.setOnMouseClicked(this::handleLable);
        label3.setAlignment(Pos.CENTER_RIGHT);
        label3.setOnMouseClicked(this::handleLable);
        topLabels.getChildren().addAll(label1, label2, label3);
        
        HBox firstLane = new HBox();
        firstLane.getChildren().addAll(symbolLane1);
        firstLane.setAlignment(Pos.CENTER);
        HBox secondLane = new HBox();
        secondLane.getChildren().addAll(symbolLane2);
        secondLane.setAlignment(Pos.CENTER);
        HBox thirdLane = new HBox();
        thirdLane.getChildren().addAll(numberLane);
        thirdLane.setAlignment(Pos.CENTER);
        HBox fourthLane = new HBox();
        fourthLane.getChildren().addAll(letterLane1);
        fourthLane.setAlignment(Pos.CENTER);
        HBox fifthLane = new HBox();
        fifthLane.getChildren().addAll(letterLane2);
        fifthLane.getChildren().add(delete);
        fifthLane.setAlignment(Pos.CENTER);
        HBox sixthLane = new HBox();
        sixthLane.getChildren().add(leftShift);
        sixthLane.getChildren().addAll(letterLane3);
        sixthLane.getChildren().add(rightShift);
        sixthLane.setAlignment(Pos.CENTER);
        HBox seventhLane = new HBox();
        seventhLane.getChildren().add(space);
        seventhLane.setAlignment(Pos.CENTER);
        textField.setPrefSize(700, 70);
        textField.setFont(Font.font(20));
        VBox layout = new VBox();
        layout.getChildren().addAll(topLabels,firstLane, secondLane, thirdLane, fourthLane, fifthLane, sixthLane, seventhLane, textField);
        this.getChildren().add(layout);
    }
    
    /**
     * event handler to handle when user presse the buttons
     * @param event 
     */
    public void handleMousePressed(ActionEvent event)
    {
        for(Button b :symbolLane1 )
        {
            if(event.getSource()==b)
            {
                text+=b.getText();
                textField.setText(text);
                getSuggestion(text);
            }
        }
        for(Button b :symbolLane2 )
        {
            if(event.getSource()==b)
            {
                text+=b.getText();
                textField.setText(text);
                getSuggestion(text);
            }
        }
         for(Button b : numberLane )
        {
            if(event.getSource()==b)
            {
                text+=b.getText();
                textField.setText(text);
                getSuggestion(text);
            }
        }
        for(Button b : letterLane1 )
        {
            if(event.getSource()==b)
            {
                text+=b.getText();
                textField.setText(text);
                getSuggestion(text);
            }
        }
        for(Button b : letterLane2 )
        {
            if(event.getSource()==b)
            {
                text+=b.getText();
                textField.setText(text);
                getSuggestion(text);
            }
        }
        for(Button b : letterLane3)
        {
            if(event.getSource()==b)
            {
                text+=b.getText();
                textField.setText(text);
                getSuggestion(text);
            }
        }
        if(event.getSource()==delete)
        {
                text = text.substring(0,text.length()-1);
                textField.setText(text);
                getSuggestion(text);
                if(text.length()<1)
                {
                    label1.setText("");
                    label2.setText("");
                    label3.setText("");
                }
        }
        if(event.getSource()==space)
        {
                text+=space.getText();
                textField.setText(text);
                getSuggestion(text);
        }
    }
    
    /**
     * shift case handler, while user pressed the shift, the letter keyboard change cases
     * @param event 
     */
    public void shiftChangeCase(MouseEvent event)
    {
        switch (shift)
        {
            case SHIFTOFF:
                shift = SHIFTON;
                for(Button b : letterLane1)
                {
                    b.setText(b.getText().toUpperCase());
                }
                for(Button b: letterLane2)
                {
                    b.setText(b.getText().toUpperCase());
                }
                for(Button b: letterLane3)
                {
                    b.setText(b.getText().toUpperCase());
                }
                break;
            case SHIFTON:
                shift = SHIFTOFF;
                for(Button b : letterLane1)
                {
                    b.setText(b.getText().toLowerCase());
                }
                for(Button b : letterLane2)
                {
                    b.setText(b.getText().toLowerCase());
                }
                for(Button b : letterLane3)
                {
                    b.setText(b.getText().toLowerCase());
                }
                break;
        }
    }
    
    /**
     * call the trie to get the candidates, and using it to set up the labels
     * @param prefix 
     */
    public void getSuggestion(String prefix)
    {
        suggestions = new ArrayList<>();
        for(Candidate c : trie.getCandidates(prefix))
        {
            suggestions.add(c);
        }
        suggestions.sort(Collections.reverseOrder());
        if(suggestions.size()>=3)
        {
            label1.setText(suggestions.get(0).toString());
            label2.setText(suggestions.get(1).toString());
            label3.setText(suggestions.get(2).toString());
        }
        if(suggestions.size()==2)
        {
            label1.setText(suggestions.get(0).toString());
            label2.setText(suggestions.get(1).toString());
            label3.setText("");
        }
        if(suggestions.size()==1)
        {
            label1.setText(suggestions.get(0).toString());
            label2.setText("");
            label3.setText("");
        }
        if(suggestions.isEmpty())
        {
            label1.setText("");
            label2.setText("");
            label3.setText("");
        }

    }
    
    /**
     * handle label while user presse the label, change the text file and getSuggestions
     * @param event 
     */
    public void handleLable(MouseEvent event)
    {
        if(event.getSource()==label1)
        {
            String s = "";
            for(char c : label1.getText().toCharArray())
            {
                if(c!='('&&c!=')')
                {
                    if(!Character.isDigit(c))
                    {
                        s+=c;
                    }
                }
            }
            text=s;
            textField.setText(text);
            getSuggestion(text);
        }
        if(event.getSource()==label2)
        {
            String s = "";
            for(char c : label2.getText().toCharArray())
            {
                if(c!='('&&c!=')')
                {
                    if(!Character.isDigit(c))
                    {
                        s+=c;
                    }
                }
            }
            text=s;
            textField.setText(text);
            getSuggestion(text);
        }
       if(event.getSource()==label3)
        {
            String s = "";
            for(char c : label3.getText().toCharArray())
            {
                if(c!='('&&c!=')')
                {
                    if(!Character.isDigit(c))
                    {
                        s+=c;
                    }
                }
            }
            text=s;
            textField.setText(text);
            getSuggestion(text);
        }
       event.consume();
    }
    
    /**
     * method to initialize everything in the keyboard
     */
    public void createKeyBoard()
    {
        shift = SHIFTOFF;
        symbolLane1 = new Button[13];
        symbolLane2 = new Button[13];
        numberLane = new Button[10];
        letterLane1 = new Button[10];
        letterLane2 = new Button[9];
        letterLane3 = new Button[7];
        delete = new Button("Delete");
        delete.setPrefSize(100, 50);
        delete.setFont(Font.font(20));
        delete.setOnAction(this::handleMousePressed);
        leftShift = new Button("Shift");
        leftShift.setFont(Font.font(18));
        leftShift.setOnMousePressed(this::shiftChangeCase);
        leftShift.setPrefSize(70, 50);
        rightShift = new Button("Shift");
        rightShift.setFont(Font.font(18));
        rightShift.setOnMousePressed(this::shiftChangeCase);
        rightShift.setPrefSize(70, 50);
        space = new Button(" ");
        space.setPrefSize(400, 50);
        space.setOnAction(this::handleMousePressed);
        textField = new TextField();
        text = "";
        String symbol1 [] = {"!","#","$","%","^","&","*","(",")","{","}","[","]"};
        String symbol2 [] = {"@","<",">",",",".","/","|","\\","+","=","-","_","?"};
        String num [] = {"1","2","3","4","5","6","7","8","9","0"};
        String letter1[] = {"q","w","e","r","t","y","u","i","o","p"};
        String letter2[] = {"a","s","d","f","g","h","j","k","l"};
        String letter3[] = {"z","x","c","v","b","n","m"};
        for(int i = 0; i<symbol1.length; i++)
        {
            symbolLane1[i] = new Button(symbol1[i]);
            symbolLane1[i].setPrefSize(50,50);
            symbolLane1[i].setFont(Font.font(20));
            symbolLane1[i].setOnAction(this::handleMousePressed);
        }
        
        for(int i = 0; i<symbol2.length; i++)
        {
            symbolLane2[i] = new Button(symbol2[i]);
            symbolLane2[i].setPrefSize(50,50);
            symbolLane2[i].setFont(Font.font(20));
            symbolLane2[i].setOnAction(this::handleMousePressed);
        }
        for(int i = 0; i<num.length; i++)
        {
            numberLane[i] = new Button(num[i]);
            numberLane[i].setPrefSize(50,50);
            numberLane[i].setFont(Font.font(20));
            numberLane[i].setOnAction(this:: handleMousePressed);
        }
        for(int i = 0; i<letter1.length;i++)
        {
            letterLane1[i] = new Button(letter1[i]);
            letterLane1[i].setPrefSize(50, 50);
            letterLane1[i].setFont(Font.font(20));
            letterLane1[i].setOnAction(this::handleMousePressed);
        }
        for(int i = 0; i< letter2.length; i++)
        {
            letterLane2[i] = new Button(letter2[i]);
            letterLane2[i].setPrefSize(50, 50);
            letterLane2[i].setFont(Font.font(20));
            letterLane2[i].setOnAction(this::handleMousePressed);
        }
        for(int i = 0; i<letter3.length; i++)
        {
            letterLane3[i] = new Button(letter3[i]);
            letterLane3[i].setMinSize(50, 50);
            letterLane3[i].setFont(Font.font(20));
            letterLane3[i].setOnAction(this::handleMousePressed);
        }

    }
    
    
    
}
