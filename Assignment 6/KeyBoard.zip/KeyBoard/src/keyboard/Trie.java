// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lectrue Section: CMPT381
package keyboard;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author yid164
 */
public class Trie {
        private TrieNode root;
        String content = "";
        ArrayList<Candidate> candidates;
        ArrayList<Candidate> candidates1;
        Candidate candidate;

    public Trie() {
        root = new TrieNode('@');
        candidates = new ArrayList<>();
    }

    public void insert(String word) {
        TrieNode current = root;
        TrieNode child;
        for (char ch : word.toCharArray()) {
            child = current.getChild(ch);
            if (child != null) {
                current = child;
            } else {
                current.childList.add(new TrieNode(ch));
                current = current.getChild(ch);
            }
            current.charCount++;
        }
        current.isLeaf = true;
        current.wordCount++;
        candidates.add(new Candidate(word, current.wordCount));
    }
    

    public boolean search(String word) {
        TrieNode current = root;
        for (char ch : word.toCharArray()) {
            if (current.getChild(ch) == null) {
                return false;
            } else {
                current = current.getChild(ch);
            }
        }
        if (current.isLeaf) {
            return true;
        }
        return false;
    }
    
    
    public void readFile()
    {
        File folder = new File("BoxFX-for-A6");
        File[] listOfFiles = folder.listFiles();
        
        for(File file : listOfFiles)
        {
            
            FileReader reader = null;
            try{
                reader = new FileReader(file);
                char[] chars = new char[(int)file.length()];
                reader.read(chars);
                content = new String(chars); 
                reader.close();
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            for(String s : content.split(" |\\(|\\)|\\,|\\."))
            {
                insert(s);
            }
            
        }
        
    }
    public void printTrie() {
        root.printNode("");
    }
    
    public void delete(String word)
    {
        if(search(word)==false)
        {
            return;
        }
        TrieNode current = root;
        for(char c : word.toCharArray())
        {
            TrieNode child = current.getChild(c);
            if(child.isLeaf)
            {
                current.childList.remove(child);
                return;
            }
            else
            {
                child.charCount--;
                current = child;
            }
        }
        current.isLeaf = false;
        
    }
    
    public ArrayList<Candidate> getCandidates(String prefix)
    {
        candidates1 = new ArrayList<>();
        for(Candidate c : candidates)
        {
            if(c.getCandidateName().startsWith(prefix))
            {
                candidates1.add(c);
            }
        }
        return candidates1;
    }
    

    public void sortCandidates()
    {
        for(int i = 0; i< candidates.size(); i++)
        {
            for(int j = 0; j<candidates.size(); j++)
            {
                if(candidates.get(i).isSameCandidateName(candidates.get(j)))
                {
                    if(candidates.get(i).compareTo(candidates.get(j))>0)
                    {
                        candidates.remove(j);
                    }
                    else
                    {
                        candidates.get(i).setFrequency(candidates.get(j).getFrequency());
                        candidates.remove(j);
                    }
                }
            }
        }
    } 
    
}
