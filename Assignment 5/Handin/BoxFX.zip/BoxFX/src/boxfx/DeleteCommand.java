/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;

/**
 * Name: Yinsheng Dong
 * Student Number: 11148648
 * NSID: yid164
 * Lecture Section: CMPT 381
 */
public class DeleteCommand implements BoxCommand {
    
    InteractionModel iModel;
    ArrayList<Groupable> groups;
    ArrayList<Groupable> deleted;
    public DeleteCommand(InteractionModel aModel, ArrayList<Groupable> groups)
    {
        iModel = aModel;
        this.groups = groups;
        deleted = new ArrayList<>();
    }

    @Override
    public void redo() {
        doIt();
    }

    @Override
    public void undo() {
        if(!groups.isEmpty())
        {
            for(Groupable g : groups)
            {
                if(g.hasChildren())
                {
                    iModel.createGroup(groups);
                }
                else
                {
                    iModel.createBox(g.getLeft(), g.getTop());
                }
            }
        }
        else
        {
            System.out.println("Groups is empty");
        }
    }
    
    @Override
    public String toString()
    {
        int x = (int) groups.get(0).getLeft();
        int y = (int) groups.get(0).getTop();
        return "Delete: "+ x+ "," + y;
    }

    @Override
    public void doIt() {
        if(!groups.isEmpty())
        {
            for(Groupable g : groups)
            {
                if(g.hasChildren())
                {
                    iModel.deleteGroup(g);
                }
                else
                {
                    iModel.deleteBox(g.getLeft(), g.getTop());
                }
            }
        }
        else
        {
            System.out.println("Groups is empty");
        }
    }
    
}
