/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;

/**
 * Name: Yinsheng Dong
 * Student Number: 11148648
 * NSID: yid164
 * Lecture Section: CMPT 381
 */
public class MoveCommand implements BoxCommand {

    InteractionModel iModel;
    ArrayList<Groupable> groups;
    double startX, startY;
    double endX, endY;
    
    public MoveCommand(InteractionModel aModel, ArrayList<Groupable> groups, double x, double y, double x1, double y1)
    {
        iModel = aModel;
        this.groups = groups;
        startX = x;
        startY = y;
        endX = x1;
        endY = y1;
    }
    
    @Override
    public void redo() {
        doIt();
    }

    @Override
    public void undo() {
        iModel.moveBack(groups, startX, startY, endX, endY);
    }

    @Override
    public void doIt() {
        iModel.moveGroup(groups, startX, startY, endX, endY);
    }
    
    @Override
    public String toString()
    {
        int x = (int) startX;
        int y = (int) startY;
        return "Move: " + x + "," + y;
    }
    
}
