
package boxfx;

import java.util.ArrayList;
import java.util.Stack;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

/**
 * Name: Yinsheng Dong
 * Student Number: 11148648
 * NSID: yid164
 * Lecture Section: CMPT 381
 * 
 */
public class InteractionModel {
    ArrayList<Groupable> groups;
    ArrayList<Groupable> reGroups;
    Stack<BoxCommand> undoStack;
    Stack<BoxCommand> redoStack;
    BoxModel bModel;
    int countAction;
    ObservableList undo = FXCollections.observableArrayList();
    ObservableList redo = FXCollections.observableArrayList();
    
    public InteractionModel()
    {
        groups = new ArrayList<>();
        reGroups = new ArrayList<>();
        undoStack = new Stack<>();
        redoStack = new Stack<>();
        
    }
    /**
     * method for managing the undo and redo
     * @param c 
     */
    public void performCommand(BoxCommand c)
    {
        c.doIt();
        undoStack.push(c);
        redoStack.clear();
        undo.add(c.toString());
        redo.clear();
        bModel.notifySubscribers();
        System.out.println("Performed the"+ c +"command");
    }
    
    /**
     * method for managing the undo
     * @param event 
     */
    public void handle_undo(ActionEvent event)
    {
        if(undoStack.empty())
        {
            System.out.println("Nothing more can undo");
            return;
        }
        BoxCommand c = undoStack.pop();
        c.undo();
        redo.add(c.toString());
        undo.remove(c.toString());
        redoStack.push(c);
        event.consume();
    }
    
    /**
     * method for managing the redo
     * @param event 
     */
    public void handle_redo(ActionEvent event)
    {
        if(redoStack.empty())
        {
            System.out.println("Nothing more can redo");
            return;
        }
        BoxCommand c = redoStack.pop();
        c.redo();
        undo.add(c.toString());
        redo.remove(c.toString());
        undoStack.push(c);
        event.consume();
    }
    
  
    
    public void setBModel(BoxModel aModel)
    {
        bModel = aModel;

    }
    
    /**
     * method for creating a box when using CreateCommand, and for recreating a box when use DeleteCommand undo
     * @param x
     * @param y 
     */
    public void createBox(double x, double y)
    {
        bModel.createBox(x, y);
    }
    
    /**
     * method for creating a group when using CreateCommand, and for recreating a group when use DeleteCommand undo
     * @param gs
     */
    public void createGroup(ArrayList<Groupable>gs)
    {
        bModel.createGroup(gs);
        bModel.notifySubscribers();
    }
    
    /**
     * method for deleting a group when using DeleteCommand, and for redeleting a group when use CrateCommand undo
     * @param g
     */
    public void deleteGroup(Groupable g)
    {
        bModel.deleteGroup(g);
    }
    
    /**
     * method for deleting a box when using DeleteCommand, and for redeleting a box when use CrateCommand undo
     * @param x
     * @param y 
     */
    public void deleteBox(double x, double y)
    {
        for(int i = 0; i<bModel.groups.size();i++)
        {   
            Box b = new Box(bModel.groups.get(i).getLeft(),bModel.groups.get(i).getTop());
            if(b.contains(x, y))
            {
                bModel.deleteGroup(bModel.groups.get(i));
            }
        }
    }
    
    /**
     * method for using moveCommand to move the group or box to a new place
     * @param gs
     * @param startX
     * @param startY
     * @param endX
     * @param endY 
     */
    public void moveGroup(ArrayList<Groupable> gs, double startX, double startY, double endX, double endY)
    {
        double x = endX - startX;
        double y = endY - startY;
        for(Groupable g : gs)
        {
            g.moveTo(x, y);
        }
        bModel.notifySubscribers();
    }
    
    /**
     * method for using moveCommand to move back to the original place
     * @param gs
     * @param startX
     * @param startY
     * @param endX
     * @param endY 
     */
    public void moveBack(ArrayList<Groupable> gs, double startX, double startY, double endX, double endY)
    {
        double x = -(endX - startX);
        double y = -(endY - startY);
        for(Groupable g : gs)
        {
            g.moveTo(x, y);
        }
        bModel.notifySubscribers();
    }
    
    /**
     * method for using copy/paste function to copy a group
     * @param gs 
     */
    public void copiedGroup(ArrayList<Groupable> gs)
    {
        for (Groupable g : gs) {
            if(g.hasChildren())
            {
                copiedGroup(g.getChildren());
            }
            else
            {
                Box b = new Box(g.getLeft()+10,g.getTop()+10);
                groups.add(b);
            }
        }
    }
    
    /**
     * method for using copy/paste function to regroup the group elements
     */
    public void reGroup()
    {
        bModel.createGroup(groups);
    }
    
    /**
     * method for using copy/paste function to copy a box 
     * @param g 
     */
    public void copiedBox(Groupable g)
    {
        bModel.createBox(g.getLeft()+50, g.getTop()+50);
    }
    
    /**
     * method for using cut function to delete a group
     * @param gs 
     */
    public void cutGroups(ArrayList<Groupable> gs)
    {
        for(Groupable g : gs)
        {
            bModel.deleteGroup(g);
        }
    }
    
    
    
    
    
}
