/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * Name: Yinsheng Dong
 * Student Number: 11148648
 * NSID: yid164
 * Lecture Section: CMPT 381
 */
public class Group implements Groupable {

    ArrayList<Groupable> groups;
    double left, top, right, bottom;

    public Group() {
        groups = new ArrayList<Groupable>();
        left = Double.MAX_VALUE;
        top = Double.MAX_VALUE;
        right = 0;
        bottom = 0;
    }

    public void add(Groupable g) {
        groups.add(g);
        left = Math.min(g.getLeft(), left);
        top = Math.min(g.getTop(), top);
        right = Math.max(g.getRight(), right);
        bottom = Math.max(g.getBottom(), bottom);
    }

    public void remove(Groupable g) {
        groups.remove(g);
    }

    public boolean hasChildren() {
        return true;
    }

    public boolean contains(double x, double y) {
        // if any member of the group contains x,y return true
        boolean found = false;
        for (Groupable g : groups) {
            if (g.contains(x, y)) {
                found = true;
            }
        }
        return found;
    }

    public boolean inRectangle(double x1, double y1, double x2, double y2) {
        // if ALL members of the group are in the rect, return true
        boolean allIn = true;
        for (Groupable g : groups) {
            if (!g.inRectangle(x1, y1, x2, y2)) {
                allIn = false;
            }
        }
        return allIn;
    }

    public void drawGroup(GraphicsContext gc) {
        for (Groupable g : groups) {
            g.drawGroup(gc);
        }
        gc.setStroke(Color.BLACK);
        gc.strokeRect(left, top, right-left, bottom-top);
        System.out.println("bbox: " + left + "," + top + "," + right + "," + bottom);
    }

    public double getLeft() {
        return left;
    }

    public double getRight() {
        return right;
    }

    public double getTop() {
        return top;
    }

    public double getBottom() {
        return bottom;
    }
    
    public ArrayList<Groupable> getChildren() {
        return groups;
    }
    
    public void moveTo(double x, double y)
    {

        for(Groupable g : groups)
        {
            g.moveTo(x, y);
        }
        left = left + x;
        top = top + y;
        right = right + x;
        bottom = bottom + y;
    }
    

}
