/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;

/**
 * Name: Yinsheng Dong
 * Student Number: 11148648
 * NSID: yid164
 * Lecture Section: CMPT 381
 */
public class CreateCommand implements BoxCommand {

    InteractionModel iModel;
    ArrayList<Groupable> groups;
    ArrayList<String> undo_message;
    ArrayList<String> redo_message;
    double x, y;
    
    public CreateCommand(InteractionModel aModel, ArrayList<Groupable> groups, double x, double y)
    {
        this.groups = groups;
        undo_message = new ArrayList<>();
        redo_message = new ArrayList<>();
        iModel = aModel;
        this.x = x;
        this.y = y;
    }
    @Override
    public void redo() 
    {
        doIt();
        
    }

    @Override
    public void undo() 
    {
        iModel.deleteBox(x, y);
    }
    
    @Override
    public String toString()
    {
        int x0 = (int) this.x;
        int y0 = (int) this.y;
        return "Create: " + x0 +" , "+ y0;
    }

    @Override
    public void doIt() {
        iModel.createBox(x, y);
        redo_message.add(toString());
    }
    
}
