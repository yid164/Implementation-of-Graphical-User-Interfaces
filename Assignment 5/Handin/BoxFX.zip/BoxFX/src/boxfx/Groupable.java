/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;
import javafx.scene.canvas.GraphicsContext;

/**
 * Name: Yinsheng Dong
 * Student Number: 11148648
 * NSID: yid164
 * Lecture Section: CMPT 381
 */
public interface Groupable {
    boolean hasChildren();
    ArrayList<Groupable> getChildren();
    boolean contains(double x, double y);
    boolean inRectangle(double x1, double y1, double x2, double y2);
    void drawGroup(GraphicsContext gc);
    double getLeft();
    double getRight();
    double getTop();
    double getBottom();
    void moveTo(double x, double y);
    
}
