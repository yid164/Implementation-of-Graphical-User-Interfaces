/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * Name: Yinsheng Dong
 * Student Number: 11148648
 * NSID: yid164
 * Lecture Section: CMPT 381
 * 
 */
public class BoxFX extends Application {

    @Override
    public void start(Stage primaryStage) {
        BoxModel model = new BoxModel();
        InteractionModel iModel = new InteractionModel();
        BoxView view = new BoxView(500, 500);
        BoxViewController controller = new BoxViewController();
        view.setController(controller);
        view.setModel(model);
        model.addSubscriber(view);
        controller.setView(view);
        controller.setModel(model);
        controller.setInteractionModel(iModel);
        BoxClipboard bcb = new BoxClipboard();
        controller.setClipboard(bcb);
        bcb.setInteractionModel(iModel);
        iModel.setBModel(model);

        for (int i = 0; i < 10; i++) {
            model.createBox(Math.random() * 400, Math.random() * 400);
        }

        HBox root = new HBox();
        Label undoStack = new Label("Undo Stack");
        undoStack.setFont(Font.font(18));
        Button undoButton = new Button("Undo!");
        undoButton.setFont(Font.font(20));
        undoButton.setOnAction(iModel::handle_undo);
        ListView undoView = new ListView();
        undoView.setEditable(false);
        undoView.setItems(iModel.undo);
        
        VBox undo = new VBox();
        undo.getChildren().addAll(undoStack, undoView, undoButton);
        undo.setAlignment(Pos.CENTER);
        
        
        Label redoStack = new Label ("Redo Stack");
        redoStack.setFont(Font.font(18));
        Button redoButton = new Button("Redo!");
        redoButton.setFont(Font.font(20));
        ListView redoView = new ListView();
        redoView.setItems(iModel.redo);
        redoButton.setOnAction(iModel::handle_redo);
        VBox redo = new VBox();
        redo.getChildren().addAll(redoStack,redoView, redoButton);
        redo.setAlignment(Pos.CENTER);
        root.getChildren().addAll(undo, view, redo);
        

        Scene scene = new Scene(root);

        primaryStage.setTitle("Box Selections");
        primaryStage.setScene(scene);
        primaryStage.show();

        root.setOnKeyPressed(controller::handleKeyPressed);
        root.setOnKeyReleased(controller::handleKeyReleased);
        
        root.requestFocus();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
