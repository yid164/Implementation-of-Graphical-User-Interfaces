/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

/**
 * Name: Yinsheng Dong
 * Student Number: 11148648
 * NSID: yid164
 * Lecture Section: CMPT 381
 */
public class BoxViewController {

    BoxModel model;
    BoxView view;
    ArrayList<Box> selectedBoxes;
    ArrayList<Groupable> selectedGroups;
    Group movingGroups;
    InteractionModel iModel;
    BoxClipboard clipboard;

    int state = 0;
    final int STATE_READY = 0;
    final int STATE_RECTSELECT = 1;
    final int STATE_MOVE = 2;
    double moveX1;
    double moveY1;
    double moveX2;
    double moveY2;
    Box box;
    boolean moving;

    boolean controlDown;
    double rectSelectX1, rectSelectY1, rectSelectX2, rectSelectY2;

    public BoxViewController() {
        selectedGroups = new ArrayList<>();
        movingGroups = new Group();
        controlDown = false;
    }
    
    public void setClipboard(BoxClipboard bcp)
    {
        clipboard = bcp;
    }

    public void setModel(BoxModel bModel) {
        model = bModel;
    }

    public void setView(BoxView bView) {
        view = bView;
    }
    
    public void setInteractionModel(InteractionModel aModel)
    {
        iModel = aModel;
    }
    

    public void handleMousePressed(MouseEvent event) {
        switch (state) {
            case STATE_READY:
                if (!controlDown) {
                    selectedGroups.clear();
                }
                if(event.isSecondaryButtonDown())
                {
                    CreateCommand c = new CreateCommand(iModel, selectedGroups, event.getX(),event.getY());
                    iModel.performCommand(c);
                    addRemoveSelection(model.findClick(event.getX(), event.getY()));
                    
                }
                
                // add to or remove from current selection
                if (model.contains(event.getX(), event.getY())) {
                    // click is on a box
                    addRemoveSelection(model.findClick(event.getX(), event.getY()));
                    moveX1 = event.getX();
                    moveY1 = event.getY();
                    moveX2 = event.getX();
                    moveY2 = event.getY();
                    state = STATE_MOVE;
                } else {
                    // click is on the background, so start a rectangle select
                    rectSelectX1 = event.getX();
                    rectSelectY1 = event.getY();
                    rectSelectX2 = event.getX();
                    rectSelectY2 = event.getY();
                    state = STATE_RECTSELECT;
                }
               
                break;
        }
        view.modelChanged();
    }

    public void handleMouseDragged(MouseEvent event) {
        switch (state) {
            case STATE_RECTSELECT:
                rectSelectX2 = event.getX();
                rectSelectY2 = event.getY();
                break;
            case STATE_MOVE:
                MoveCommand c = new MoveCommand(iModel, selectedGroups, moveX1, moveY1, event.getX(), event.getY());
                moveX1 = event.getX();
                moveY1 = event.getY();
                iModel.performCommand(c);
                break;       
        }
        view.modelChanged();
    }

    public void handleMouseReleased(MouseEvent event) {
        switch (state) {
            case STATE_RECTSELECT:
                addRemoveSelection(model.findInRectangle(rectSelectX1, rectSelectY1, rectSelectX2, rectSelectY2));
                break;
   
        }
        state = STATE_READY;
        view.modelChanged();
    }

    public void handleKeyPressed(KeyEvent event) {
        if (event.getCode() == KeyCode.CONTROL) {
            controlDown = true;
            view.modelChanged();
        }
        if(event.getCode() == KeyCode.C && controlDown)
        {
            System.out.println("Copy");
            clipboard.copy(selectedGroups);
        }
        if(event.getCode() == KeyCode.V && controlDown)
        {
            System.out.println("Paste");
            System.out.println(clipboard.clips);
            clipboard.paste();
        }
        if(event.getCode() == KeyCode.X && controlDown)
        {
            System.out.println("Cut");
            clipboard.cut(selectedGroups);
        }
    }

    public void handleKeyReleased(KeyEvent event) {
        if (event.getCode() == KeyCode.CONTROL) {
            controlDown = false;
        } else if (event.getCode() == KeyCode.G) {
            System.out.println("G");
            if (selectedGroups.size() > 0) {
                Groupable tempGroup = model.createGroup(selectedGroups);
                selectedGroups.clear();
                selectedGroups.add(tempGroup);
            }
        } else if (event.getCode() == KeyCode.U) {
            System.out.println("U");
            if (selectedGroups.size() == 1 && selectedGroups.get(0).hasChildren()) {
                ArrayList<Groupable> items = model.ungroup(selectedGroups.get(0));
                selectedGroups.clear();
                addRemoveSelection(items);
            }
        }
        else if(event.getCode() == KeyCode.BACK_SPACE || event.getCode()==KeyCode.DELETE)
        {
            System.out.println("Delete");
            DeleteCommand c = new DeleteCommand(iModel,selectedGroups);
            iModel.performCommand(c);
        }
        view.modelChanged();
    }

    private void addRemoveSelection(Groupable sGroup) {
        if (selectedGroups.contains(sGroup)) {
            selectedGroups.remove(sGroup);
        } else {
            selectedGroups.add(sGroup);
        }
    }

    private void addRemoveSelection(ArrayList<Groupable> sGroups) {
        for (Groupable g : sGroups) {
            addRemoveSelection(g);
        }
    }
    


//    private void addRemoveSelection(Box sBox) {
//        if (selectedBoxes.contains(sBox)) {
//            selectedBoxes.remove(sBox);
//        } else {
//            selectedBoxes.add(sBox);
//        }
//    }
//
//    private void addRemoveSelection(ArrayList<Box> sBoxes) {
//        for (Box b : sBoxes) {
//            addRemoveSelection(b);
//        }
//    }
}
