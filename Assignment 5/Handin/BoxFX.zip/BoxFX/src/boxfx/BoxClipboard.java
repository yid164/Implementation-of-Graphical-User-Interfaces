/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;

/**
 * Name: Yinsheng Dong
 * Student Number: 11148648
 * NSID: yid164
 * Lecture Section: CMPT 381
 */
public class BoxClipboard {
    ArrayList<Groupable> clips;
    InteractionModel iModel;
    ArrayList<Groupable> pasted;
    
    
    public void setInteractionModel(InteractionModel aModel)
    {
        iModel = aModel;
    }
    
    public BoxClipboard()
    {
        clips = new ArrayList<>();
        pasted = new ArrayList<>();
    }
    
    public void paste()
    { 
        for(Groupable g: clips)
        {
            if(g.hasChildren())
            {
                iModel.copiedGroup(clips);
                iModel.reGroup();
            }
            else
            {
                iModel.copiedBox(g);
            }
        }
    }
    
    public void copy (ArrayList<Groupable> gs)
    {
        clips.clear();
        for(Groupable g : gs)
        {
            clips.add(g);
        }
    }
    
    public void cut(ArrayList<Groupable> gs)
    {
        copy(gs);
        iModel.cutGroups(gs);
    }
}
