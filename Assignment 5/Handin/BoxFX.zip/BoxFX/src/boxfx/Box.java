/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * Name: Yinsheng Dong
 * Student Number: 11148648
 * NSID: yid164
 * Lecture Section: CMPT 381
 */
public class Box implements Groupable {

    double x, y;
    double w, h;

    public Box(double newX, double newY) {
        x = newX;
        y = newY;

        w = 25;
        h = 25;
    }

    public boolean hasChildren() {
        return false;
    }

    public boolean contains(double tX, double tY) {
        return tX >= x && tX <= x + w && tY >= y && tY <= y + h;
    }

    public boolean inRectangle(double x1, double y1, double x2, double y2) {
        return x >= x1 && x + w <= x2 && y >= y1 && y + h <= y2;
    }

    public void drawGroup(GraphicsContext gc) {
        gc.fillRect(x, y, w, h);
        gc.setStroke(Color.BLACK);
        gc.strokeRect(x, y, w, h);
    }
    
    public double getLeft() {
        return x;
    }

    public double getRight() {
        return x+w;
    }

    public double getTop() {
        return y;
    }

    public double getBottom() {
        return y+h;
    }
    
    public ArrayList<Groupable> getChildren() {
        return null;
    }
    
    public void moveTo(double x, double y)
    {
        this.x += x;
        this.y += y;
    }
    
}
