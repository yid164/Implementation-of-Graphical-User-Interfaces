/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boxfx;

import java.util.ArrayList;

/**
 * Name: Yinsheng Dong
 * Student Number: 11148648
 * NSID: yid164
 * Lecture Section: CMPT 381
 */
public class BoxModel {
    //ArrayList<Box> boxes;
    ArrayList<Groupable> groups;
    //BoxView view;
    ArrayList<BoxModelListener> subscribers;

    public BoxModel() {

        //boxes = new ArrayList<Box>();
        groups = new ArrayList<Groupable>();
        subscribers = new ArrayList<BoxModelListener>();
    }

    public void createBox(double x, double y) {
        //boxes.add(new Box(x,y));
        groups.add(new Box(x,y));
        notifySubscribers();
    }
    
    public Groupable createGroup(ArrayList<Groupable> gs) {
        Group newGroup = new Group();
        for (Groupable g : gs) {
            groups.remove(g);
            newGroup.add(g);
        }
        groups.add(newGroup);
        return newGroup;
    }
    
    
    public ArrayList<Groupable> ungroup(Groupable g) {
        ArrayList<Groupable> items = new ArrayList<Groupable>();
        for (Groupable child : g.getChildren()) {
            items.add(child);
            groups.add(child);
        }
        groups.remove(g);
        return items;
    }

    public void addSubscriber (BoxModelListener sub) {
        subscribers.add(sub);
    }

    public void notifySubscribers() {
        for (BoxModelListener bml : subscribers) {
            bml.modelChanged();
        }
    }

    public boolean contains(double x, double y) {
        boolean found = false;
//        for (Box b : boxes) {
//            if (b.contains(x,y)) {
//                found = true;
//            }
//        }
        for (Groupable g : groups) {
            if (g.contains(x,y)) {
                found = true;
            }
        }
        return found;
    }

    public Groupable findClick(double x, double y) {
        Groupable foundGroup = null;
        for (Groupable g : groups) {
            if (g.contains(x, y)) {
                foundGroup = g;
            }
        }
        return foundGroup;
        
//        Box foundBox = null;
//        for (Box b : boxes) {
//            if (b.contains(x,y)) {
//                foundBox = b;
//            }
//        }
//        return foundBox;
    }
    
    public ArrayList<Groupable> findInRectangle(double x1, double y1, double x2, double y2) {
        ArrayList<Groupable> foundGroups = new ArrayList<Groupable>();
        for (Groupable g : groups) {
            if (g.inRectangle(x1,y1,x2,y2)) {
                foundGroups.add(g);
            }
        }
        return foundGroups;        
    }
    
//    public ArrayList<Box> findInRectangle(double x1, double y1, double x2, double y2) {
//        ArrayList<Box> foundBoxes = new ArrayList<Box>();
//        for (Box b : boxes) {
//            if (b.inRectangle(x1,y1,x2,y2)) {
//                foundBoxes.add(b);
//            }
//        }
//        return foundBoxes;        
//    }

    public void moveBox(Box b, double newX, double newY) {
        b.x = newX;
        b.y = newY;
        notifySubscribers();
    }
    
    public void moveGroupable(Groupable g, double newX, double newY)
    {
        g.moveTo(newX, newY);
    }

    public void deleteGroup(Groupable g) {
        groups.remove(g);
        notifySubscribers();
    }
}
