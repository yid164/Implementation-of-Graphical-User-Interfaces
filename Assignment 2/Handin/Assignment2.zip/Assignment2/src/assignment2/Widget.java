// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381
package assignment2;


import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 *
 * @author yid164
 */
public class Widget {
    
    double width;
    double height;
    double maxWidth;
    double maxHeight;
    double minWidth;
    double minHeight;
    double prefWidth;
    double prefHeight;
    double x;
    double y;
    GraphicsContext gc;
    
    
    
    /**
     * sets the widget's min width and height
     * @param newMinWidth
     * @param newMinHeight 
     */
    public void setMinSize(double newMinWidth, double newMinHeight)
    {
        minWidth = newMinWidth;
        minHeight = newMinHeight;
    }
    
    /**
     * set the widget's max width and height
     * @param newMaxWidth
     * @param newMaxHeight 
     */
    public void setMaxSize (double newMaxWidth, double newMaxHeight)
    {
        maxWidth = newMaxWidth;
        maxHeight = newMaxHeight;       
    }
    
    /**
     * set the widget's preferred width and height
     * @param newPrefWidth
     * @param newPrefHeight 
     */
    public void setPrefSize (double newPrefWidth, double newPrefHeight)
    {
        prefWidth = newPrefWidth;
        prefHeight = newPrefHeight;
    }

    /**
     * draw a rectangle to indicate the position and size of the widget
     * the rectangle is red if the widget is at its min width, orange if between min and preferred with
     * green if preferred width, purple if between preferred and max width
     * blue if at max width
     * draw lines from corner to corner to clearly show the size of the widget rectangle
     * @param gc 
     */
    public void drawWidget(GraphicsContext gc)
    {
        if(width == prefWidth)
        {
            gc.setFill(Color.GREEN);
            gc.fillRect(x, y, width, height);
        }
        if(width >= maxWidth)
        {
            gc.setFill(Color.BLUE);
            gc.fillRect(x, y, width, height);
        }
        
        if(width < minWidth)
        {
            gc.setFill(Color.RED);
            gc.fillRect(x, y, width, height);
        }
        
        if(width > prefWidth && width < maxWidth)
        {
            gc.setFill(Color.PURPLE);
            gc.fillRect(x, y, width, height);
        }
        
        if(width < prefWidth && width > minWidth)
        {
            gc.setFill(Color.ORANGE);
            gc.fillRect(x, y, width, height);
        }
        
        gc.fillRect(x, y, width, height);
        gc.setStroke(Color.BLACK);
        gc.strokeLine(x,y, width+x, height+y);
        gc.strokeLine(x, height+y, width+x, y);
    }
    
    
    public Widget(double width,double height)
    {
        x = 0;
        y = 0;
        this.width = width;
        this.height = height;
    }
    
}
