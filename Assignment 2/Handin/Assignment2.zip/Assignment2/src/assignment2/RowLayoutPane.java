// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381
package assignment2;


import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;


/**
 *
 * @author yid164
 */
public  class RowLayoutPane extends Pane{
    
    boolean top;
    boolean center;
    boolean fill;
    Widget topWidget;
    Widget centerWidget;
    Widget fillWidget;
    Widget [] widget;
    RowCell rowCell;
    RowCell left;
    RowCell right;
    RowCell mid;
    GraphicsContext gc;
    Canvas canvas;
    double x;
    double y;
    
    /**
     * adds a widget object to the list for this container, 
     * and creates a RowCell to hold the widget
     * @param w 
     */
    public void addWidget(Widget w)
    {
        widget = new Widget[3];
        widget[0] = topWidget;
        widget[1] = centerWidget;
        widget[2] = fillWidget;
        rowCell.addWidget(w);
        
    }
    
    /**
     * set the given widget's vertical position as Top, Center, or fill
     * @param w
     * @param position 
     */
    
    public void setVerticalPosition(Widget w, int position)
    {
        if(position == 0)
        {   
            rowCell = right;
            topWidget = new Widget(200,200);
            w = topWidget;
            addWidget(w);
            rowCell.top = true;
        }
        if (position == 1)
        {
            rowCell = left;
            centerWidget = new Widget(300,200);
            w = centerWidget;
            addWidget(w);
            rowCell.center = true;
        }
        if (position == 2)
        {
            rowCell = mid;
            fillWidget = new Widget(300,400);
            w = fillWidget;
            addWidget(w);
            rowCell.fill = true;
        }
        
    }
    
    
    /***
     * calculates the positions and sizes of all widgets in the list
     */
    public void doLayout()
    {
        rowCell.positionWidgetVertical();
        if(rowCell.fill)
        {
            fillWidget.setPrefSize(300, 400);
            fillWidget.setMinSize(250, 200);
            fillWidget.setMaxSize(400,500);
            rowCell.x = left.cellWidth;
            addWidget(fillWidget);
        }
        
        if(rowCell.center)
        {
            centerWidget.setPrefSize(300, 200);
            centerWidget.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
            centerWidget.setMinSize(300, 200);
            rowCell.x = 0;
            addWidget(centerWidget);
        }
        
        if(rowCell.top)
        {
            topWidget.setPrefSize(200, 200);
            topWidget.setMaxSize(300, 300);
            topWidget.setMinSize(100, 200);
            rowCell.x = left.cellWidth + mid.cellWidth;
            addWidget(topWidget);
        }
        
        
    }
    
    /**
     * draws the current layout to the canvas
     */
    public void drawRow()
    {
        Widget widget1 = new Widget(0,0);
        Widget widget2 = new Widget(0,0);
        Widget widget3 = new Widget(0,0);
        setVerticalPosition(widget2, 1);
        doLayout();
        rowCell.drawCell(gc);
        setVerticalPosition(widget3,2);
        doLayout();
        rowCell.drawCell(gc);
        setVerticalPosition(widget1, 0);
        doLayout();
        rowCell.drawCell(gc);
        

        
        
    }
    
    /**
     * override the original layoutChildren();
     * to re-setup the left right mid cell
     */
    @Override
    public void layoutChildren()
    {
        gc.getCanvas().setWidth(this.getWidth());
        gc.getCanvas().setHeight(this.getHeight());
        left.cellHeight = gc.getCanvas().getHeight();
        left.cellWidth = gc.getCanvas().getWidth() * 3/8;
        right.cellHeight = gc.getCanvas().getHeight();
        right.cellWidth = gc.getCanvas().getWidth() * 2/8;
        mid.cellHeight = gc.getCanvas().getHeight();
        mid.cellWidth = gc.getCanvas().getWidth() * 3/8;
        if (this.getWidth()<=350)
        {
            mid.cellWidth = 250;
            right.cellWidth = 100;
            left.cellWidth = 300;
        }
        else
        {
            drawRow();
        }
    }
   


    
    public RowLayoutPane()
    {  
        left = new RowCell(300,500);
        right = new RowCell(200,500);
        mid = new RowCell(300,500);
        canvas = new Canvas();
        gc = canvas.getGraphicsContext2D();
        drawRow();
        getChildren().add(canvas);
        this.setPrefSize(800, 500);
        
        
        
    }
    
}
