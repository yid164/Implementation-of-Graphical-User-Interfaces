// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381
package assignment2;


import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 *
 * @author yid164
 */
public class RowCell{
    
    double cellWidth;
    double cellHeight;
    Widget widget;
    double x;
    double y;
    boolean top;
    boolean center;
    boolean fill;
    
    
    /**
     *  associates a widget object with this cell
     * @param w 
     */
    public void addWidget(Widget w)
    {
        widget = new Widget(0,0);
        widget = w;
    }
    
    /**
     * draws an oval to indicate the bounds of this cell, then asks the widget to draw itself
     * 
     * @param gc 
     */
    public void drawCell(GraphicsContext gc)
    {
        gc.setFill(Color.GRAY);
        gc.fillRect(x, y,cellWidth, cellHeight);
        gc.setStroke(Color.WHITE);
        gc.strokeOval(x, y, cellWidth, cellHeight);
        positionWidgetVertical();
        widget.drawWidget(gc);
        
    }
    /**
     * sets the vertical position and height of the widget, given its positioning constraint
     */
    public void positionWidgetVertical()
    {
        if(top)
        {
            
            widget.height = cellHeight/2;
            widget.width = cellWidth;
            widget.x = x;
            widget.y = y;
            addWidget(widget);
        }
        
        if(fill)
        {
            widget.height = cellHeight;
            widget.width = cellWidth;
            widget.x = x;
            widget.y = y;
            addWidget(widget);
        }
        
        if(center)
        {
            widget.height = cellHeight/2;
            widget.x = x;
            widget.y = cellHeight/4;
            widget.width = cellWidth;
            addWidget(widget);
        }
    }
    
    public RowCell(double cellWidth, double cellHeight)
    {
        x = 0;
        y = 0;
        top = false;
        fill = false;
        center = false;
        this.cellWidth = cellWidth;
        this.cellHeight = cellHeight;
        
    }
    
}
