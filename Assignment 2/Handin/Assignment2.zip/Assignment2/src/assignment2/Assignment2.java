// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381
package assignment2;



import java.util.Random;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javafx.geometry.Insets;
import javafx.geometry.Pos;

import javafx.scene.Scene;

import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;

import javafx.stage.Stage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 *
 * @author yid164
 */
public class Assignment2 extends Application {
    
    
    // varialbe for label
    Label label;
    /**
     * to initialize the label and set variable
     * @return label 
     */
    Label label()
    {
        label = new Label("ListView Selection: none");
        label.setPrefWidth(500);
        label.setAlignment(Pos.CENTER_RIGHT);
        return label;
    }
    /**
     * *the menu bar that assignment require
     * @return menuBar
     */
    MenuBar menuBar()
    {
        MenuBar menuBar = new MenuBar();
        Menu menuFile = new Menu("File");
        Menu menuEdit = new Menu("Edit");
        Menu menuView = new Menu("View");
        MenuItem[] itemInFile = new MenuItem[10];
        for (int i = 0; i<10; i++) 
        {
            itemInFile[i]= new MenuItem("File Item "+i);
            menuFile.getItems().addAll(itemInFile[i]);
        }
        
        MenuItem[] itemInEdit = new MenuItem[10];
        for(int i =0; i<10; i++)
        {
            itemInEdit[i] = new MenuItem("File Item "+ i);
            menuEdit.getItems().addAll(itemInEdit[i]);
        }
        
        MenuItem[] itemInView = new MenuItem[10];
        for(int i =0; i<10; i++)
        {
            itemInView[i] = new MenuItem("File Item "+ i);
            menuView.getItems().addAll(itemInView[i]);
        }
        menuBar.getMenus().addAll(menuFile,menuEdit,menuView);
        return menuBar;
    }
    
    
    /**
     * the list view that assignment require
     * @return listView
     */
    ListView list()
    {
        ListView<String> list = new ListView<String>();
        ObservableList<String>  items = FXCollections.observableArrayList(
        "TRANSPARENT", "ALICEBLUE","ANTIQUEWHITE","AQUA","AQUAMARINE","AZURE",
                "BEIGE","BISQUE","BLACK","BLANCHEDALMOND","BLUE","BLUEVOILET",
                "BROWN","BURLYWOOD","CADETBLUE","CHARTREUSE","CHOCOLATE","CORAL",
                "CORNFLOWERBLUE","CORNSILK","CRIMSON","CYAN");
        list.setItems(items);
        list.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>(){
        public void changed (ObservableValue<? extends String> ov,String old_val, String new_val)
        {
                label.setText("ListView Selection:" + new_val);
            }
        });
        return list;
    }
    
    /**
     * the flowPane that store 40 circle objects
     * @return the flow pane
     */
    FlowPane flowPane()
    {
        FlowPane flowPane = new FlowPane();
        flowPane.setPadding(new Insets(5,0,5,0));
        flowPane.setPrefWrapLength(200);
        for(int i = 0; i<40; i++)
        {
  
            Random randColor = new Random();
            double r = randColor.nextDouble();
            double g = randColor.nextDouble();
            double b = randColor.nextDouble();
            Circle a = new Circle();
            a.setFill(Color.color(r, g, b));
            a.setRadius(25);
            flowPane.getChildren().add(a);
        }
        return flowPane;
    }
    
    
    @Override
    public void start(Stage primaryStage) {

        primaryStage.setTitle("A2");
        BorderPane layout = new BorderPane();
        layout.setTop(menuBar());
        layout.setRight(list());
        layout.setLeft(flowPane());
        layout.setBottom(label());
        RowLayoutPane rp = new RowLayoutPane();

        layout.setCenter(rp);


        Scene scene = new Scene(layout,1248,500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
