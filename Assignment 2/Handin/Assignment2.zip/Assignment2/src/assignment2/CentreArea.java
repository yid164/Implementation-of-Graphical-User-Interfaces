// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381
package assignment2;



import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

/**
 *
 * @author yid164
 */
public class CentreArea extends Pane {

    Canvas canvas;
    GraphicsContext gc;
    

    
    @Override
    public void layoutChildren()
    {
        gc.getCanvas().setWidth(this.getWidth());
        gc.getCanvas().setHeight(this.getHeight());
        drawCanvasContents();
    }
    
    public void drawCanvasContents()
    {
        gc.setFill(Color.BLUE);
        gc.fillRect(0,0,canvas.getWidth(),canvas.getHeight());
        gc.setStroke(Color.WHITE);
        gc.strokeOval(0, 0, canvas.getWidth(), canvas.getHeight());
    }
    
    public CentreArea()
    {
        VBox layout = new VBox();
        canvas = new Canvas(500,500);
        gc = canvas.getGraphicsContext2D();
        layout.getChildren().add(canvas);
        getChildren().add(layout);
    }
    
}
