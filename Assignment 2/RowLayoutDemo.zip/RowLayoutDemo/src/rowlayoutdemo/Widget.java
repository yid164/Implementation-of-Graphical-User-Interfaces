/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rowlayoutdemo;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 *
 * @author gutwin
 */
public class Widget {

    double x, y, width, height;
    double minW, minH;
    double maxW, maxH;
    double prefW, prefH;

    public Widget(float newW, float newH) {
        width = newW;
        height = newH;
        prefW = width;
        prefH = height;
        // defaults for min and max
        minW = width * 0.5;
        minH = height * 0.5;
        maxW = prefW;
        maxH = prefH;
    }

    public void setMinSize(double newMinWidth, double newMinHeight) {
        minW = newMinWidth;
        minH = newMinHeight;
    }

    public void setMaxSize(double newMaxWidth, double newMaxHeight) {
        maxW = newMaxWidth;
        maxH = newMaxHeight;
    }

    void drawWidget(GraphicsContext gc) {
        if (width == minW) {
            gc.setFill(Color.RED);
        } else if (width > minW && width < prefW) {
            gc.setFill(Color.ORANGE);
        } else if (width == prefW) {
            gc.setFill(Color.GREEN);
        } else if (width > prefW && width < maxW) {
            gc.setFill(Color.PURPLE);
        } else if (width == maxW) {
            gc.setFill(Color.BLUE);
        }
        gc.fillRect(x, y, width, height);
        gc.setStroke(Color.BLACK);
        gc.strokeRect(x,y,width,height);
        gc.strokeLine(x, y, x + width, y + height);
        gc.strokeLine(x, y + height, x + width, y);
    }
}
