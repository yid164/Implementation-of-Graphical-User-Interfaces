/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rowlayoutdemo;

import java.lang.reflect.Field;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 *
 * @author gutwin
 */
public class RowLayoutDemo extends Application {

    RowLayoutPane rlp;
    BorderPane myBorderPane;

    @Override
    public void start(Stage primaryStage) {
        // Use border pane for toplevel layout
        myBorderPane = new BorderPane();

        // Label for statusbar
        Label label6 = new Label("ListView Selection: none");
        //label6.setStyle("-fx-background-color: lightgray");
        label6.setFont(Font.font("Arial", 20));
        label6.setAlignment(Pos.CENTER);
        label6.setMaxWidth(Double.MAX_VALUE);

        // ListView
        ListView<String> list = new ListView<>();
        ObservableList<String> items = FXCollections.observableArrayList();
        final Field[] fields = Color.class.getFields();
        for (Field f : fields) {
            items.add(f.getName());
        }
        list.setItems(items);
        list.getSelectionModel().selectedItemProperty().addListener((ov, old_val, new_val)
                -> label6.setText("ListView Selection: " + new_val));

        // FlowPane
        FlowPane flow = new FlowPane(Orientation.HORIZONTAL);
        flow.setPrefWrapLength(200);
        for (int i = 0; i < 40; i++) {
            Circle c = new Circle(25, Color.color(Math.random(), Math.random(), Math.random()));
            flow.getChildren().add(c);
        }

        // Menu        
        MenuBar menuBar = new MenuBar();
        Menu menuFile = new Menu("File");
        for (int i = 1; i <= 10; i++) {
            menuFile.getItems().add(new MenuItem("File Item " + i));
        }
        Menu menuEdit = new Menu("Edit");
        for (int i = 1; i <= 10; i++) {
            menuEdit.getItems().add(new MenuItem("Edit Item " + i));
        }
        Menu menuView = new Menu("View");
        for (int i = 1; i <= 10; i++) {
            menuView.getItems().add(new MenuItem("View Item " + i));
        }
        menuBar.getMenus().addAll(menuFile, menuEdit, menuView);

        // new custom layout pane
        rlp = new RowLayoutPane();
        Widget w1 = new Widget(400, 200);
        w1.setMinSize(300, 200);
        //w1.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
        w1.setMaxSize(450, Double.MAX_VALUE);
        rlp.addWidget(w1);
        rlp.setVerticalPosition(w1, RowLayoutPane.ALIGN_MIDDLE);
        Widget w2 = new Widget(300, 400);
        w2.setMinSize(250, 200);
        w2.setMaxSize(400, 500);
        rlp.addWidget(w2);
        rlp.setVerticalPosition(w2, RowLayoutPane.ALIGN_FILL_HEIGHT);
        Widget w3 = new Widget(200, 200);
        w3.setMinSize(100, 200);
        w3.setMaxSize(300, 300);
        rlp.addWidget(w3);
        rlp.setVerticalPosition(w3, RowLayoutPane.ALIGN_TOP);

        // simple canvas pane (for Part 1)
        SimpleCanvasPane scp = new SimpleCanvasPane();
        
        // Add components to borderpane
        myBorderPane.setTop(menuBar);
        myBorderPane.setBottom(label6);
        myBorderPane.setLeft(flow);
        myBorderPane.setRight(list);
        myBorderPane.setCenter(rlp);
        //myBorderPane.setCenter(scp);
        
        Scene scene = new Scene(myBorderPane);
        primaryStage.setTitle("Layout Demo");
        primaryStage.setScene(scene);
        System.out.println("after set scene");
        primaryStage.show();
        System.out.println("after stage show");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
