/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rowlayoutdemo;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 *
 * @author gutwin
 */
public class RowCell {

    double x, y, cellWidth, cellHeight;
    Widget widget = null;
    int verticalPosition;
    
    public RowCell() {
        x = 0;
        y = 0;
        cellWidth = 0;
        cellHeight = 0;
    }

    public void addWidget(Widget w) {
        widget = w;
        verticalPosition = RowLayoutPane.ALIGN_TOP;
    }

    public void setPosition(int position) {
        verticalPosition = position;
    }

    void drawCell(GraphicsContext gc) {
        // draw cell
        gc.setStroke(Color.WHITE);
        gc.strokeOval(x, y, cellWidth, cellHeight);

        // draw widget in this cell
        widget.drawWidget(gc);
    }

    void positionWidgetVertical() {
        if (verticalPosition == RowLayoutPane.ALIGN_MIDDLE) {
            widget.y = Math.max(y + cellHeight / 2 - widget.height / 2, 0);
        } else if (verticalPosition == RowLayoutPane.ALIGN_FILL_HEIGHT) {
            widget.y = y;
            widget.height = cellHeight;
        } else { // verticalPosition == RowLayoutPane.ALIGN_TOP
            widget.y = y;
            widget.height = widget.prefH;
        }
    }
}
