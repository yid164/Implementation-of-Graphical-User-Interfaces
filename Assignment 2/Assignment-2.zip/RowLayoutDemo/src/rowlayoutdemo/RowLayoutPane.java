/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rowlayoutdemo;

import java.util.ArrayList;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

/**
 *
 * @author gutwin
 */
public class RowLayoutPane extends Pane {
    // graphics
    GraphicsContext gc;
    Canvas myCanvas;
    
    // layout
    ArrayList<RowCell> cells;
    double width, height;
    double minWidth, minHeight;
    double prefWidth, prefHeight;
    double maxWidth, maxHeight;
    double actualWidth, actualHeight;
    boolean resizing = false;

    // positioning
    static int ALIGN_TOP = 0;
    static int ALIGN_MIDDLE = 1;
    static int ALIGN_FILL_HEIGHT = 2;

    public RowLayoutPane() {
        cells = new ArrayList<>();
        myCanvas = new Canvas();
        gc = myCanvas.getGraphicsContext2D();
        getChildren().add(myCanvas);
    }

    private void drawRow() {
        gc.setFill(Color.GRAY);
        gc.fillRect(0, 0, width, height);
        // draw cells
        cells.forEach(rc -> rc.drawCell(gc));
    }

    public void addWidget(Widget w) {
        RowCell rc = new RowCell();
        rc.addWidget(w);
        cells.add(rc);
        
        calculateWidth();
        this.setPrefSize(prefWidth,prefHeight);
    }

    public void setVerticalPosition(Widget w, int position) {
        boolean found = false;
        for (RowCell rc : cells) {
            if (rc.widget == w) {
                found = true;
                rc.setPosition(position);
            }
        }
        if (!found) {
            // exception: widget w is not in the rowLayoutPane
            System.err.println("Widget not found in cell list");
        }
    }

    @Override
    public void layoutChildren() {
        // method from Pane that will be called by the toolkit when the window resizes
        width = this.getWidth();
        height = this.getHeight();
        myCanvas.setWidth(width);
        myCanvas.setHeight(height);
        doLayout();
    }

    public void doLayout() {
        // layout width
        calculateWidth();
        if (width <= minWidth) {
            // give all children minimum, and let them be clipped
            double childX = 0;
            for (RowCell rc : cells) {
                rc.x = childX;
                rc.widget.x = childX;
                rc.widget.width = rc.widget.minW;
                rc.cellWidth = rc.widget.width;
                childX += rc.cellWidth;
            }
        } else if (width <= prefWidth) {
            // give min to all and then proportional based on extra available
            double prefMargin = prefWidth - minWidth;
            double fraction = (width - minWidth) / prefMargin;
            double childX = 0;
            for (RowCell rc : cells) {
                rc.x = childX;
                rc.widget.x = childX;
                rc.widget.width = rc.widget.minW + (rc.widget.prefW - rc.widget.minW) * fraction;
                rc.cellWidth = rc.widget.width;
                childX += rc.cellWidth;
            }
        } else { // width > prefWidth
            for (RowCell rc : cells) {
                rc.widget.width = rc.widget.prefW;
                rc.cellWidth = rc.widget.width;
            }
            calculateWidth();
            // allocate extra based on maximum widths
            while (actualWidth < maxWidth && actualWidth < width) {
                calculateWidth();
                //System.out.println("\t\twidth > prefWidth");
                double extra = width - actualWidth;
                //System.out.println("extra: " + extra);
                double fraction = extra / actualWidth;
                //System.out.println("fraction: " + fraction);
                double childX = 0;
                for (RowCell rc : cells) {
                    rc.x = childX;
                    rc.widget.x = childX;
                    if (rc.widget.width < rc.widget.maxW) {
                        rc.widget.width = Math.min(rc.widget.width + rc.widget.width * fraction, rc.widget.maxW);
                    }
                    rc.cellWidth = rc.widget.width;
                    childX += rc.cellWidth;
                }
            }
        }
        // Height layout        
        for (RowCell rc : cells) {
            rc.cellHeight = height;
            rc.positionWidgetVertical();
        }
        // layout finished, so redraw
        drawRow();
    }

    public void calculateWidth() {
        // min width of children
        minWidth = 0;
        cells.forEach(rc -> minWidth += rc.widget.minW);
        // pref width of children
        prefWidth = 0;
        cells.forEach(rc -> prefWidth += rc.widget.prefW);
        // max width of children
        maxWidth = 0;
        cells.forEach(rc -> maxWidth += rc.widget.maxW);
        // actual width of children
        actualWidth = 0;
        cells.forEach(rc -> actualWidth += rc.widget.width);
    }
}
