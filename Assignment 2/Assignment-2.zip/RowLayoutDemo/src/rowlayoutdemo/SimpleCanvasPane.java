/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rowlayoutdemo;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

/**
 *
 * @author gutwin
 */
public class SimpleCanvasPane extends Pane {
    // graphics

    GraphicsContext gc;
    Canvas myCanvas;

    public SimpleCanvasPane() {
        myCanvas = new Canvas(500, 500);
        gc = myCanvas.getGraphicsContext2D();
        getChildren().add(myCanvas);
        drawCanvas();
        this.setPrefSize(500, 500);
        this.setMinSize(100, 100);
        this.setMaxSize(1000, 1000);
    }

    private void drawCanvas() {
        gc.setFill(Color.BLUE);
        gc.fillRect(0, 0, myCanvas.getWidth(), myCanvas.getHeight());
        gc.setStroke(Color.WHITE);
        gc.strokeOval(0, 0, myCanvas.getWidth(), myCanvas.getHeight());
    }

    @Override
    public void layoutChildren() {
        // method from Pane that will be called by the toolkit when the window resizes
        myCanvas.setWidth(this.getWidth());
        myCanvas.setHeight(this.getHeight());
        drawCanvas();
    }
}
