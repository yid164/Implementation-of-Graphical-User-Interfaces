package com.example.gutwin.graphdemo;

/**
 * Created by gutwin on 2017-02-04.
 */

public class Edge {
    Vertex start, end;

    public Edge(Vertex newStart, Vertex newEnd) {
        start = newStart;
        end = newEnd;
    }
}
