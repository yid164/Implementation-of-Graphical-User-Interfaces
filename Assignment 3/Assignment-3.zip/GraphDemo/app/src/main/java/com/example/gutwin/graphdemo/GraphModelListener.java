package com.example.gutwin.graphdemo;

/**
 * Created by gutwin on 2017-02-04.
 */

public interface GraphModelListener {
    void modelChanged();
}
