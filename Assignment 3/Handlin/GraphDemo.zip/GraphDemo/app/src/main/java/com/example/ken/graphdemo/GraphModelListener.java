package com.example.ken.graphdemo;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381

public interface GraphModelListener {
    public void modelChanged();
}
