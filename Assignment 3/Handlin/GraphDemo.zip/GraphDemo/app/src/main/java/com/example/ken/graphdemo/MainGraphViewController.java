package com.example.ken.graphdemo;
// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381
import android.view.MotionEvent;
import android.view.View;

public class MainGraphViewController implements View.OnTouchListener , View.OnLongClickListener {
    GraphModel model;
    Vertex selected = null;
    Vertex longSelected = null;
    Vertex v1 = null;
    Vertex drag = null;
    MainGraphView view;
    Edge edge = null;
    int state = 0;
    final int STATE_READY = 0;
    final int STATE_PREPARE = 1;
    final int STATE_SELECTED = 2;
    final int STATE_MOVING = 3;
    final int STATE_LONG = 4;

    InputState vState;

    public void setModel(GraphModel g) {
        model = g;
    }

    public void setView(MainGraphView v) {
        view = v;
    }

    public boolean onLongClick(View v) {

        switch (state)
        {
            case STATE_SELECTED:
                longSelected = selected;
                state = STATE_LONG;
                view.invalidate();
                break;

        }


        return true;

    }


    public boolean onTouch(View v, MotionEvent event) {
        float touchX = event.getX();
        float touchY = event.getY();

        switch (state) {
            case STATE_READY:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (model.contains(touchX, touchY)) {
                            selected = model.findClick(touchX, touchY);
                            view.invalidate();
                            state = STATE_SELECTED;
                        } else {
                            state = STATE_PREPARE;
                        }
                        break;
                }
                break;
            case STATE_PREPARE:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        model.createVertices(touchX, touchY);
                        view.modelChanged();
                        state = STATE_READY;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        // cancel pending create
                        state = STATE_READY;
                        break;
                }
                break;
            case STATE_SELECTED:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        selected = null;
                        view.invalidate();
                        state = STATE_READY;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        model.moveVertex(selected, touchX, touchY);
                        if(edge != null)
                        {
                            if(selected.contains(edge.x1,edge.y1))
                            {
                                model.moveEdges(edge,edge.x,edge.y,selected.x,selected.y);
                            }
                            else if (selected.contains(edge.x,edge.y))
                            {
                                model.moveEdges(edge,selected.x,selected.y,edge.x1,edge.y1);
                            }

                        }
                        view.modelChanged();
                        state = STATE_MOVING;
                        break;
                }
                break;
            case STATE_MOVING:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        selected = null;
                        view.invalidate();
                        state = STATE_READY;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        model.moveVertex(selected, touchX, touchY);
                        if(edge != null)
                        {
                            if(selected.contains(edge.x1,edge.y1))
                            {
                                model.moveEdges(edge,edge.x,edge.y,selected.x,selected.y);
                            }
                            else if (selected.contains(edge.x,edge.y))
                            {
                                model.moveEdges(edge,selected.x,selected.y,edge.x1,edge.y1);
                            }

                        }
                        view.modelChanged();
                        break;
                }
                break;
            case STATE_LONG:
                switch (event.getAction())
                {
                    case MotionEvent.ACTION_UP:

                        if(model.contains(edge.x1,edge.y1) && model.contains(edge.x,edge.y))
                        {
                            selected = null;
                            longSelected = null;
                            model.createEdges(edge.x,edge.y,edge.x1,edge.y1);
                            view.invalidate();
                            state = STATE_READY;
                        }
                        else
                        {
                            selected = null;
                            longSelected = null;
                            edge = null;
                            view.invalidate();

                            state = STATE_READY;
                        }
                        break;
                    case MotionEvent.ACTION_MOVE:
                        v1 = selected;
                        model.createEdges(v1.x,v1.y,touchX,touchY);
                        edge = model.findEdges(v1.x,v1.y,touchX,touchY);
                        model.moveEdges(edge,v1.x,v1.y,touchX,touchY);
                        view.modelChanged();
                        break;
                }
        }

        return false;
    }
}

    /**
    public boolean onTouch(View v, MotionEvent event)
    {

        switch (event.getAction())
        {
            case MotionEvent.ACTION_UP:
                if(model.contains(event.getX(),event.getY()))
                {
                    selected = null;
                    longSelected = selected;
                    view.invalidate();
                }
                break;
            case MotionEvent.ACTION_DOWN:
                if(model.contains(event.getX(),event.getY()))
                {
                    selected = model.findClick(event.getX(),event.getY());
                    edge = model.findEdge(event.getX(),event.getY());
                    view.invalidate();
                }
                else
                {
                    model.createVertices(event.getX(),event.getY());
                    model.createEdges(event.getX(),event.getY());
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if(selected != null)
                {

                    model.moveVertex(selected, event.getX(), event.getY());
                    model.moveEdges(edge,event.getX(),event.getY());

                }
                break;

        }
**/

/**
 if (event.getAction() == MotionEvent.ACTION_DOWN )
 {
 if(model.contains(event.getX(),event.getY()))
 {
 selected = model.findClick(event.getX(),event.getY());
 view.invalidate();
 }
 else
 {
 model.createVertices(event.getX(),event.getY());
 }


 }

 else if (event.getAction() == MotionEvent.ACTION_UP)
 {
 if(model.contains(event.getX(),event.getY()))
 {
 selected = null;
 view.invalidate();
 }
 }


 else if (event.getAction() == MotionEvent.ACTION_MOVE)
 {
 if(selected != null)
 {
 model.moveVertex(selected, event.getX(), event.getY());

 }
 }

    }
 **/

