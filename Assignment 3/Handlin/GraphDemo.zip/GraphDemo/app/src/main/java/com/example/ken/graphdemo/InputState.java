package com.example.ken.graphdemo;


import android.view.MotionEvent;
// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381

public interface InputState{
    public void handleTouch (MainGraphViewController context, MotionEvent event);
}
