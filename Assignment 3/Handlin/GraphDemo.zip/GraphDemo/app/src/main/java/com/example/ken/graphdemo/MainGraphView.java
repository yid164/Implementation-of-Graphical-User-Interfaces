package com.example.ken.graphdemo;

import android.content.Context;
import android.content.pm.LabeledIntent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.icu.text.AlphabeticIndex;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381

public class MainGraphView extends View implements GraphModelListener{

    Paint myPaint;
    GraphModel model;
    MainGraphViewController controller;
    Paint labelText;
    Paint line;
    public MainGraphView(Context c)
    {
        super(c);
        myPaint = new Paint();
        myPaint.setColor(Color.BLUE);
        labelText= new Paint();
        labelText.setColor(Color.WHITE);
        labelText.setTextSize(60);
        line = new Paint();
        line.setColor(Color.BLACK);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(20);

        this.setBackgroundColor(Color.GRAY);
    }

    public void setModel (GraphModel aModel)
    {
        model = aModel;
    }

    public void setController (MainGraphViewController mgc)
    {
        controller = mgc;
    }

    public void modelChanged()
    {
        invalidate();
    }

    public void onDraw (Canvas myCanvas)
    {

        for(Vertex v : model.vertices)
        {
            if(v == controller.selected) {

                if (v==controller.longSelected&&v == controller.selected)
                {
                    myPaint.setColor(Color.YELLOW);
                    myCanvas.drawOval(v.x-50, v.y-50, v.x+50, v.y+50, myPaint);
                    myCanvas.drawText("v"+model.vertices.indexOf(v),v.x-30,v.y+20,labelText);
                    myCanvas.drawOval(v.x-50, v.y-50, v.x+50, v.y+50, line);
                    for(Edge e:model.edges)
                    {
                        if(e==controller.edge)
                        {
                            myCanvas.drawLine(e.x,e.y,e.x1,e.y1,line);
                        }

                    }
                    this.modelChanged();


                }
                else {
                    myPaint.setColor(Color.YELLOW);
                    myCanvas.drawOval(v.x-50, v.y-50, v.x+50, v.y+50, myPaint);
                    myCanvas.drawText("v"+model.vertices.indexOf(v),v.x-30,v.y+20,labelText);
                    for(Edge e:model.edges)
                    {
                        if(e==controller.edge)
                        {
                            myCanvas.drawLine(e.x,e.y,e.x1,e.y1,line);
                        }

                    }
                    this.modelChanged();



                }

            }



            else
            {
                myPaint.setColor(Color.BLUE);
                myCanvas.drawOval(v.x-50, v.y-50, v.x+50, v.y+50, myPaint);
                myCanvas.drawText("v"+model.vertices.indexOf(v),v.x-30,v.y+20,labelText);
                for(Edge e:model.edges)
                {
                    if(e==controller.edge)
                    {
                        myCanvas.drawLine(e.x,e.y,e.x1,e.y1,line);
                    }

                }
                this.modelChanged();

            }



        }

    }

}
