package com.example.ken.graphdemo;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381

public class Vertex {
    float x, y;
    public Vertex (float newX, float newY)
    {
        x = newX;
        y = newY;
    }

    public boolean contains (float tX, float tY)
    {
        return tX >= x-50 && tX <= x + 50 && tY >= y-50 && tY <= y+50;
    }
}
