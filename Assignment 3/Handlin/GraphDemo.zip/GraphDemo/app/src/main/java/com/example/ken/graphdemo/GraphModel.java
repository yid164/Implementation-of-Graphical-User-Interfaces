package com.example.ken.graphdemo;

import java.util.ArrayList;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381

public class GraphModel {
    ArrayList<Vertex> vertices;
    ArrayList<Edge> edges;
    ArrayList<GraphModelListener> subscribers;

    MainGraphView view;

    public GraphModel()
    {
        vertices = new ArrayList<Vertex>();
        edges = new ArrayList<Edge>();
    }

    public void createVertices(float x, float y)
    {
        vertices.add(new Vertex(x,y));
        view.modelChanged();
    }

    private void notifySubscribers()
    {
        for(GraphModelListener gml : subscribers)
        {
            gml.modelChanged();
        }
    }
    public void createEdges (float x, float y, float x1, float y1)
    {
        edges.add(new Edge(x,y,x1, y1));
        view.modelChanged();
    }

    public void setView(MainGraphView aView)
    {
        view = aView;
    }

    public boolean contains(float x, float y)
    {
        boolean found = false;
        for (Vertex v : vertices)
        {
            if(v.contains(x,y))
            {
                found = true;
            }
        }
        return found;
    }


    public boolean contiansEdge(float x, float y, float x1, float y1)
    {
        boolean found = false;
        for(Edge e : edges)
        {
            if(e.contains(x,y,x1,y1));
        }
        return found;
    }


    public Vertex findClick(float x, float y)
    {
        Vertex foundClick = null;
        for (Vertex v : vertices)
        {
            if(v.contains(x,y))
            {
                foundClick = v;
            }
        }
        return  foundClick;
    }


    public Edge findEdges(float x, float y, float x1, float y1)
    {
        Edge foundEdge = null;
        for(Edge e : edges)
        {
            if(e.contains(x,y,x1,y1))
            {
                foundEdge = e;
            }
        }
        return foundEdge;
    }


    public void moveVertex (Vertex v, float newX, float newY)
    {
        v.x = newX;
        v.y = newY;
        view.modelChanged();
    }



    public void deleteVertex(Vertex v)
    {
        vertices.remove(v);
        notifySubscribers();
    }

    public void deleteEdges(Edge e)
    {
        edges.remove(e);
        view.modelChanged();
    }

    public void moveEdges (Edge e, float x, float y, float x1, float y1)
    {
        e.x = x;
        e.y = y;
        e.x1 = x1;
        e.y1= y1;
        view.modelChanged();
    }
}
