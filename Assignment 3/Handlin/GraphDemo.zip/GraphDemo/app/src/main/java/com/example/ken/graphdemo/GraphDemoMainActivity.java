package com.example.ken.graphdemo;
// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381
import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class GraphDemoMainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MainGraphView gView = new MainGraphView(this);
        GraphModel model = new GraphModel();
        MainGraphViewController controller = new MainGraphViewController();

        controller.setModel(model);
        gView.setModel(model);
        model.setView(gView);
        gView.setController(controller);
        controller.setView(gView);

        gView.setOnTouchListener(controller);
        gView.setOnLongClickListener(controller);
        setContentView(gView);
    }
}
