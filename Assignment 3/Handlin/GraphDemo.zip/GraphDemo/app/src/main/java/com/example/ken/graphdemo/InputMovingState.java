package com.example.ken.graphdemo;

import android.view.MotionEvent;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381

public class InputMovingState implements InputState {

    public void handleTouch(MainGraphViewController context, MotionEvent event)
    {
        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:
                if(context.model.contains(event.getX(),event.getY()))
                {
                    context.selected = context.model.findClick(event.getX(),event.getY());
                    context.view.invalidate();
                    context.vState = new InputSelectedState();
                }
                else
                {
                    context.vState = new InputPrepareState();
                }
                break;
        }
    }
}
