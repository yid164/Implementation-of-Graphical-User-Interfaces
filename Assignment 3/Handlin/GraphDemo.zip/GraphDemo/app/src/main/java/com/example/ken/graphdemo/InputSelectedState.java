package com.example.ken.graphdemo;

import android.view.MotionEvent;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381

public class InputSelectedState implements InputState {

    public void handleTouch(MainGraphViewController context, MotionEvent event)
    {
        switch (event.getAction())
        {
            case MotionEvent.ACTION_UP:
                context.selected = null;
                context.view.invalidate();
                context.vState = new InputReadyState();
                break;
            case MotionEvent.ACTION_MOVE:
                context.model.moveVertex(context.selected, event.getX(),event.getY());
                context.vState = new InputMovingState();
                break;
        }

    }
}
