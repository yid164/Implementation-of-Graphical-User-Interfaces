package com.example.ken.graphdemo;

import android.view.MotionEvent;

// Name: Yinsheng Dong
// Student Number: 11148648
// NSID: yid164
// Lecture Section: CMPT 381

public class InputPrepareState implements InputState {
    public void handleTouch(MainGraphViewController context, MotionEvent event)
    {
        switch (event.getAction())
        {
            case MotionEvent.ACTION_UP:
                context.model.createVertices(event.getX(),event.getY());
                context.vState = new InputReadyState();
                break;
            case MotionEvent.ACTION_MOVE:
                context.vState = new InputReadyState();
                break;
        }
    }
}
