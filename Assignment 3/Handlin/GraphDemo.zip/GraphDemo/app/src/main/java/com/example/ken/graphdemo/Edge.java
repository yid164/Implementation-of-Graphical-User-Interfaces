package com.example.ken.graphdemo;

/**
 * Created by Ken on 2017/2/12.
 */

public class Edge{
    float x, y, x1, y1;
    public Edge (float x, float y, float x1, float y1)
    {
        this.x = x;
        this.y = y;
        this.x1 = x1;
        this.y1= y1;

    }

    public boolean contains (float tX, float tY, float tX1, float tY1)
    {
        return tX >= x-50 && tX <= x + 50 && tY >= y-50 && tY <= y+50 && tX1 >= x1-50 && tX1 <= x1+50 && tY1 >= y1-50 && tY1<=y1+50;
    }
}
